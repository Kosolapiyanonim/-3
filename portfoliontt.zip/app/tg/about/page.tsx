import Link from "next/link"

export default function TelegramAboutPage() {
  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Link href="/tg" className="mr-4 p-2 bg-secondary rounded-md">
          ← Назад
        </Link>
        <h1 className="text-2xl font-bold">Обо мне</h1>
      </div>

      <div className="space-y-4">
        <p>Профессиональный разработчик с опытом создания современных веб-приложений и сайтов.</p>

        <div className="border rounded-lg p-4 bg-card">
          <h2 className="text-lg font-semibold">Опыт работы</h2>
          <div className="mt-2">
            <h3 className="font-medium">Старший разработчик</h3>
            <p className="text-sm text-muted-foreground">Компания XYZ • 2020 - настоящее время</p>
            <p className="mt-1 text-sm">
              Разработка и поддержка веб-приложений для корпоративных клиентов. Руководство командой разработчиков.
            </p>
          </div>
        </div>

        <div className="border rounded-lg p-4 bg-card">
          <h2 className="text-lg font-semibold">Образование</h2>
          <div className="mt-2">
            <h3 className="font-medium">Магистр компьютерных наук</h3>
            <p className="text-sm text-muted-foreground">Университет Технологий • 2016 - 2018</p>
            <p className="mt-1 text-sm">Специализация в области веб-разработки и искусственного интеллекта.</p>
          </div>
        </div>

        <div className="border rounded-lg p-4 bg-card">
          <h2 className="text-lg font-semibold">Навыки</h2>
          <div className="flex flex-wrap gap-2 mt-2">
            <span className="bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded">React</span>
            <span className="bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded">Next.js</span>
            <span className="bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded">Node.js</span>
            <span className="bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded">TypeScript</span>
            <span className="bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded">Tailwind CSS</span>
          </div>
        </div>
      </div>
    </div>
  )
}
