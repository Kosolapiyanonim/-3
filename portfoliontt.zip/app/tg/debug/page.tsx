"use client"

import { useEffect, useState } from "react"
import Link from "next/link"

export default function TelegramDebugPage() {
  const [telegramInfo, setTelegramInfo] = useState({
    available: false,
    expanded: false,
    theme: "unknown",
    version: "unknown",
    platform: "unknown",
    viewportHeight: 0,
    viewportStableHeight: 0,
  })

  useEffect(() => {
    if (typeof window !== "undefined") {
      const checkTelegram = () => {
        if (window.Telegram && window.Telegram.WebApp) {
          const webApp = window.Telegram.WebApp
          setTelegramInfo({
            available: true,
            expanded: webApp.isExpanded,
            theme: webApp.colorScheme,
            version: webApp.version,
            platform: webApp.platform,
            viewportHeight: webApp.viewportHeight,
            viewportStableHeight: webApp.viewportStableHeight,
          })
        }
      }

      // Проверяем сразу
      checkTelegram()

      // И через секунду
      const timer = setTimeout(checkTelegram, 1000)
      return () => clearTimeout(timer)
    }
  }, [])

  const handleExpand = () => {
    if (window.Telegram && window.Telegram.WebApp) {
      window.Telegram.WebApp.expand()

      // Обновляем состояние после расширения
      setTimeout(() => {
        setTelegramInfo((prev) => ({
          ...prev,
          expanded: window.Telegram.WebApp.isExpanded,
        }))
      }, 100)
    }
  }

  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Link href="/tg" className="mr-4 p-2 bg-secondary rounded-md">
          ← Назад
        </Link>
        <h1 className="text-2xl font-bold">Отладка Telegram WebApp</h1>
      </div>

      <div className="border rounded-lg p-4 bg-card mb-4">
        <h2 className="text-lg font-semibold mb-2">Статус Telegram WebApp</h2>
        <div className="space-y-1 text-sm">
          <p>
            <strong>Доступен:</strong> {telegramInfo.available ? "Да" : "Нет"}
          </p>
          {telegramInfo.available && (
            <>
              <p>
                <strong>Развернут:</strong> {telegramInfo.expanded ? "Да" : "Нет"}
              </p>
              <p>
                <strong>Тема:</strong> {telegramInfo.theme}
              </p>
              <p>
                <strong>Версия:</strong> {telegramInfo.version}
              </p>
              <p>
                <strong>Платформа:</strong> {telegramInfo.platform}
              </p>
              <p>
                <strong>Высота области просмотра:</strong> {telegramInfo.viewportHeight}px
              </p>
              <p>
                <strong>Стабильная высота:</strong> {telegramInfo.viewportStableHeight}px
              </p>
            </>
          )}
        </div>
      </div>

      <button
        onClick={handleExpand}
        disabled={!telegramInfo.available || telegramInfo.expanded}
        className="w-full p-3 bg-primary text-primary-foreground rounded-md disabled:opacity-50"
      >
        Развернуть вручную
      </button>
    </div>
  )
}
