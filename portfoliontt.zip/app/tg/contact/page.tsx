import Link from "next/link"

export default function TelegramContactPage() {
  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Link href="/tg" className="mr-4 p-2 bg-secondary rounded-md">
          ← Назад
        </Link>
        <h1 className="text-2xl font-bold">Контакты</h1>
      </div>

      <div className="space-y-4">
        <p>Свяжитесь со мной для обсуждения вашего проекта или сотрудничества.</p>

        <div className="border rounded-lg p-4 bg-card">
          <h2 className="text-lg font-semibold">Контактная информация</h2>
          <div className="space-y-2 mt-2">
            <div>
              <h3 className="font-medium">Email</h3>
              <p className="text-muted-foreground">contact@nttportfolio.com</p>
            </div>
            <div>
              <h3 className="font-medium">Телефон</h3>
              <p className="text-muted-foreground">+7 (999) 123-45-67</p>
            </div>
            <div>
              <h3 className="font-medium">Адрес</h3>
              <p className="text-muted-foreground">Москва, Россия</p>
            </div>
          </div>
        </div>

        <div className="border rounded-lg p-4 bg-card">
          <h2 className="text-lg font-semibold">Социальные сети</h2>
          <div className="flex flex-wrap gap-3 mt-2">
            <a href="#" className="bg-primary text-primary-foreground px-3 py-1 rounded-md text-sm">
              GitHub
            </a>
            <a href="#" className="bg-primary text-primary-foreground px-3 py-1 rounded-md text-sm">
              LinkedIn
            </a>
            <a href="#" className="bg-primary text-primary-foreground px-3 py-1 rounded-md text-sm">
              Twitter
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
