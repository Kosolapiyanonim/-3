import Link from "next/link"

export default function TelegramProjectsPage() {
  const projects = [
    {
      id: 1,
      title: "Веб-приложение для управления проектами",
      description: "React и Node.js приложение для управления проектами",
      tags: ["React", "Node.js", "MongoDB"],
    },
    {
      id: 2,
      title: "Мобильное приложение для фитнеса",
      description: "React Native приложение для отслеживания тренировок",
      tags: ["React Native", "Firebase"],
    },
    {
      id: 3,
      title: "Корпоративный сайт",
      description: "Современный корпоративный сайт с адаптивным дизайном",
      tags: ["Next.js", "Tailwind CSS"],
    },
  ]

  return (
    <div className="p-4">
      <div className="flex items-center mb-6">
        <Link href="/tg" className="mr-4 p-2 bg-secondary rounded-md">
          ← Назад
        </Link>
        <h1 className="text-2xl font-bold">Проекты</h1>
      </div>

      <div className="space-y-4">
        {projects.map((project) => (
          <div key={project.id} className="border rounded-lg p-4 bg-card">
            <h2 className="text-lg font-semibold">{project.title}</h2>
            <p className="text-muted-foreground mt-1">{project.description}</p>
            <div className="flex flex-wrap gap-2 mt-2">
              {project.tags.map((tag) => (
                <span key={tag} className="bg-secondary text-secondary-foreground text-xs px-2 py-1 rounded">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
