"use client"

import { useEffect, useState } from "react"
import { SlotMachine } from "@/components/casino/slot-machine"
import { CasinoTransition } from "@/components/casino/casino-transition"
import { motion } from "framer-motion"

export default function CasinoPage() {
  const [showTransition, setShowTransition] = useState(true)

  useEffect(() => {
    // Скрываем анимацию перехода через 2 секунды
    const timer = setTimeout(() => {
      setShowTransition(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  return (
    <motion.div
      className="container mx-auto py-6 px-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 1.5, duration: 0.5 }}
    >
      {showTransition && <CasinoTransition />}
      <motion.h1
        className="text-2xl md:text-3xl font-bold text-center mb-6 bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-500"
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 2, duration: 0.5 }}
      >
        Колесо Фортуны Услуг
      </motion.h1>
      <SlotMachine />
    </motion.div>
  )
}
