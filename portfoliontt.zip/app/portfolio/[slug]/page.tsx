"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import { GsapTextReveal } from "@/components/gsap/text-reveal"
import { GsapParallax } from "@/components/gsap/parallax"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import type { Project } from "@/types/database"

export default function ProjectDetailPage() {
  const { slug } = useParams()
  const [project, setProject] = useState<Project | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (slug) {
      fetch(`/api/projects?slug=${slug}`)
        .then((res) => res.json())
        .then((data) => {
          setProject(data)
          setLoading(false)
        })
        .catch((err) => {
          console.error("Error loading project:", err)
          setLoading(false)
        })
    }
  }, [slug])

  if (loading) {
    return (
      <div className="space-y-8 md:space-y-16 w-full animate-pulse">
        <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded w-3/4 mb-4"></div>
        <div className="h-64 bg-gray-300 dark:bg-gray-700 rounded w-full mb-4"></div>
        <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full mb-2"></div>
        <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full mb-2"></div>
        <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-5/6 mb-2"></div>
      </div>
    )
  }

  if (!project) {
    return (
      <div className="space-y-8 md:space-y-16 w-full">
        <Button asChild variant="outline" className="mb-4">
          <Link href="/portfolio">
            <ArrowLeft className="mr-2 h-4 w-4" /> Назад к портфолио
          </Link>
        </Button>
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2">Проект не найден</h2>
          <p className="text-muted-foreground">Запрашиваемый проект не существует или был удален.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8 md:space-y-16 w-full">
      <Button asChild variant="outline" className="mb-4">
        <Link href="/portfolio">
          <ArrowLeft className="mr-2 h-4 w-4" /> Назад к портфолио
        </Link>
      </Button>

      <section className="space-y-4 md:space-y-6">
        <GsapTextReveal className="text-2xl md:text-4xl font-bold">{project.title}</GsapTextReveal>

        <div className="flex flex-wrap gap-2 mb-6">
          {project.tags.map((tag) => (
            <Badge key={tag} variant="secondary">
              {tag}
            </Badge>
          ))}
        </div>

        <div className="relative h-64 md:h-96 w-full overflow-hidden rounded-lg mb-8">
          <Image src={project.image_url || "/placeholder.svg"} alt={project.title} fill className="object-cover" />
        </div>

        <GsapParallax speed={0.2} className="text-base md:text-lg text-muted-foreground mb-8">
          <p className="mb-4">{project.description}</p>
          <div dangerouslySetInnerHTML={{ __html: project.content }} />
        </GsapParallax>
      </section>
    </div>
  )
}
