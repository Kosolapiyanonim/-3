"use client"

import { useEffect, useState } from "react"
import { ProjectCard } from "@/components/project-card"
import type { Project } from "@/types/database"

export default function PortfolioPage() {
  const [projects, setProjects] = useState<Project[]>([])
  const [allTags, setAllTags] = useState<string[]>([])
  const [selectedTag, setSelectedTag] = useState<string>("all")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Загрузка проектов
    fetch("/api/projects")
      .then((res) => res.json())
      .then((data) => {
        setProjects(data)
        setIsLoading(false)

        // Извлечение всех уникальных тегов
        const tags = new Set<string>()
        data.forEach((project: Project) => {
          project.tags.forEach((tag) => tags.add(tag))
        })
        setAllTags(Array.from(tags))
      })
      .catch((err) => {
        console.error("Error loading projects:", err)
        setIsLoading(false)
      })
  }, [])

  // Фильтрация проектов
  const filteredProjects = projects.filter((project) => {
    const matchesTag = selectedTag === "all" || project.tags.includes(selectedTag)
    const matchesCategory = selectedCategory === "all" || project.category === selectedCategory
    return matchesTag && matchesCategory
  })

  // Если данные еще не загружены, показываем заглушки
  const placeholderProjects: Project[] = projects.length
    ? filteredProjects
    : [
        {
          id: 1,
          title: "Веб-приложение для управления проектами",
          slug: "project-management-app",
          description:
            "Разработка полнофункционального веб-приложения для управления проектами с использованием React и Node.js.",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["React", "Node.js", "MongoDB"],
          category: "web",
          created_at: "",
          updated_at: "",
        },
        {
          id: 2,
          title: "Мобильное приложение для фитнеса",
          slug: "fitness-mobile-app",
          description:
            "Создание мобильного приложения для отслеживания тренировок и питания с использованием React Native.",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["React Native", "Firebase", "Redux"],
          category: "mobile",
          created_at: "",
          updated_at: "",
        },
        {
          id: 3,
          title: "Корпоративный сайт для компании",
          slug: "corporate-website",
          description:
            "Разработка современного корпоративного сайта с адаптивным дизайном и системой управления контентом.",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["Next.js", "Tailwind CSS", "Strapi"],
          category: "web",
          created_at: "",
          updated_at: "",
        },
      ]

  // Категории для фильтрации
  const categories = [
    { id: "all", name: "Все" },
    { id: "web", name: "Веб" },
    { id: "mobile", name: "Мобильные" },
    { id: "design", name: "Дизайн" },
  ]

  return (
    <div className="space-y-6 md:space-y-8 w-full">
      <section className="space-y-2 md:space-y-4">
        <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold">Портфолио</h1>
        <p className="text-sm md:text-base lg:text-xl text-muted-foreground">
          Ознакомьтесь с моими последними работами в различных областях разработки.
        </p>
      </section>

      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div>
            <h3 className="text-sm font-medium mb-2">Категории</h3>
            <div className="flex flex-wrap gap-2 mb-4">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-md text-sm transition-all ${
                    selectedCategory === category.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>

          {allTags.length > 0 && (
            <div>
              <h3 className="text-sm font-medium mb-2">Теги</h3>
              <div className="flex flex-wrap gap-2 mb-4">
                <button
                  onClick={() => setSelectedTag("all")}
                  className={`px-4 py-2 rounded-md text-sm transition-all ${
                    selectedTag === "all"
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                >
                  Все теги
                </button>
                {allTags.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setSelectedTag(tag)}
                    className={`px-4 py-2 rounded-md text-sm transition-all ${
                      selectedTag === tag
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-3">
        {isLoading
          ? // Показываем скелетон загрузки
            Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="h-[300px] rounded-lg bg-muted animate-pulse" aria-hidden="true"></div>
            ))
          : // Показываем проекты
            placeholderProjects.map((project) => <ProjectCard key={project.id} project={project} />)}
      </div>
    </div>
  )
}
