"use client"

import { GsapTextReveal } from "@/components/gsap/text-reveal"
import { GsapParallax } from "@/components/gsap/parallax"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Check, ArrowRight } from "lucide-react"
import Link from "next/link"
import { useEffect, useRef } from "react"
import gsap from "gsap"

export default function ForPerformersPage() {
  const sectionsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (sectionsRef.current) {
      gsap.from(sectionsRef.current.children, {
        opacity: 0,
        y: 50,
        stagger: 0.3,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: sectionsRef.current,
          start: "top bottom-=100",
          toggleActions: "play none none none",
        },
      })
    }
  }, [])

  return (
    <div className="space-y-8 md:space-y-16 w-full">
      <section className="space-y-4 md:space-y-6">
        <GsapTextReveal className="text-2xl md:text-4xl font-bold">Исполнителям</GsapTextReveal>
        <GsapParallax speed={0.2} className="text-base md:text-xl text-muted-foreground">
          Информация для фрилансеров и специалистов, желающих присоединиться к моей команде.
        </GsapParallax>
      </section>

      <div ref={sectionsRef} className="space-y-8">
        <section className="space-y-4">
          <h2 className="text-xl md:text-2xl font-semibold">Кого я ищу</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="transform-gpu hover:scale-105 transition-transform duration-300">
              <CardContent className="p-6">
                <h3 className="font-semibold text-lg mb-4">Веб-разработчики</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Frontend (React, Next.js)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Backend (Node.js, Python)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Fullstack разработчики</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="transform-gpu hover:scale-105 transition-transform duration-300">
              <CardContent className="p-6">
                <h3 className="font-semibold text-lg mb-4">Дизайнеры</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>UI/UX дизайнеры</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Графические дизайнеры</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Иллюстраторы</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="transform-gpu hover:scale-105 transition-transform duration-300">
              <CardContent className="p-6">
                <h3 className="font-semibold text-lg mb-4">Маркетологи</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>SMM-специалисты</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Копирайтеры</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>SEO-специалисты</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl md:text-2xl font-semibold">Преимущества работы со мной</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Стабильный поток проектов</h3>
                  <p className="text-muted-foreground">Регулярные заказы и долгосрочные проекты</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Конкурентная оплата</h3>
                  <p className="text-muted-foreground">Справедливое вознаграждение за вашу работу</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Профессиональный рост</h3>
                  <p className="text-muted-foreground">Работа над интересными и сложными проектами</p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Гибкий график</h3>
                  <p className="text-muted-foreground">Работайте в удобное для вас время</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Удаленная работа</h3>
                  <p className="text-muted-foreground">Работайте из любой точки мира</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Четкие требования</h3>
                  <p className="text-muted-foreground">Ясные задачи и своевременная обратная связь</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl md:text-2xl font-semibold">Как начать сотрудничество</h2>
          <ol className="space-y-4">
            <li className="flex items-start gap-3">
              <div className="bg-primary/20 p-2 rounded-full h-8 w-8 flex items-center justify-center font-semibold">
                1
              </div>
              <div>
                <h3 className="font-semibold">Отправьте заявку</h3>
                <p className="text-muted-foreground">
                  Заполните форму на странице контактов, указав ваши навыки и опыт
                </p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="bg-primary/20 p-2 rounded-full h-8 w-8 flex items-center justify-center font-semibold">
                2
              </div>
              <div>
                <h3 className="font-semibold">Собеседование</h3>
                <p className="text-muted-foreground">Обсудим ваш опыт, навыки и ожидания от сотрудничества</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="bg-primary/20 p-2 rounded-full h-8 w-8 flex items-center justify-center font-semibold">
                3
              </div>
              <div>
                <h3 className="font-semibold">Тестовое задание</h3>
                <p className="text-muted-foreground">Небольшое задание для оценки ваших навыков</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="bg-primary/20 p-2 rounded-full h-8 w-8 flex items-center justify-center font-semibold">
                4
              </div>
              <div>
                <h3 className="font-semibold">Начало сотрудничества</h3>
                <p className="text-muted-foreground">Обсуждение условий и начало работы над проектами</p>
              </div>
            </li>
          </ol>
        </section>

        <div className="flex justify-center mt-8">
          <Button asChild size="lg">
            <Link href="/contact">
              Отправить заявку <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
