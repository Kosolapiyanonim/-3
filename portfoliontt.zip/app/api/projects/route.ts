import { createServerSupabaseClient } from "@/lib/supabase"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const category = searchParams.get("category")
  const tag = searchParams.get("tag")
  const slug = searchParams.get("slug")

  const supabase = createServerSupabaseClient()

  let query = supabase.from("projects").select("*")

  if (category) {
    query = query.eq("category", category)
  }

  if (tag) {
    query = query.contains("tags", [tag])
  }

  if (slug) {
    query = query.eq("slug", slug).single()
  }

  const { data, error } = await query

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json(data)
}
