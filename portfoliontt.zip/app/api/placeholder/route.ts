import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const type = searchParams.get("type") || "symbol"
  const width = Number.parseInt(searchParams.get("width") || "100")
  const height = Number.parseInt(searchParams.get("height") || "100")

  // Создаем SVG заглушку
  const svg = `
    <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
      <rect width="${width}" height="${height}" fill="${type === "symbol" ? "#FFD700" : "#8B0000"}" />
      <text x="50%" y="50%" font-family="Arial" font-size="${width / 4}px" fill="${type === "symbol" ? "#8B0000" : "#FFD700"}" text-anchor="middle" dominant-baseline="middle">
        ${type === "symbol" ? "?" : "SLOT"}
      </text>
    </svg>
  `

  return new NextResponse(svg, {
    headers: {
      "Content-Type": "image/svg+xml",
    },
  })
}
