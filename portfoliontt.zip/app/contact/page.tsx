import { Button } from "@/components/ui/button"
import { Mail, Phone, MapPin, Send } from "lucide-react"
import { BrandTelegram } from "@/components/icons/brand-telegram"

export default function ContactPage() {
  const contactItems = [
    {
      id: 1,
      type: "email",
      title: "Email",
      value: "contact@nttportfolio.com",
      icon: <Mail className="h-5 w-5 md:h-6 md:w-6 shrink-0 text-primary" />,
    },
    {
      id: 2,
      type: "phone",
      title: "Телефон",
      value: "+7 (999) 123-45-67",
      icon: <Phone className="h-5 w-5 md:h-6 md:w-6 shrink-0 text-primary" />,
    },
    {
      id: 3,
      type: "address",
      title: "Адрес",
      value: "Москва, Россия",
      icon: <MapPin className="h-5 w-5 md:h-6 md:w-6 shrink-0 text-primary" />,
    },
  ]

  return (
    <div className="space-y-6 md:space-y-12 w-full">
      <section className="space-y-2 md:space-y-4">
        <h1 className="text-2xl md:text-4xl font-bold">Связаться</h1>
        <p className="text-sm md:text-xl text-muted-foreground">
          Свяжитесь со мной для обсуждения вашего проекта или сотрудничества.
        </p>
      </section>

      <div className="grid grid-cols-1 gap-6 md:gap-8 md:grid-cols-2">
        <div className="space-y-4 md:space-y-6 order-2 md:order-1">
          <h2 className="text-xl md:text-2xl font-semibold">Контактная информация</h2>
          <div className="space-y-4">
            {contactItems.map((contact) => (
              <div
                key={contact.id}
                className="rounded-lg border bg-card p-4 transition-all duration-300 hover:shadow-md"
              >
                <div className="flex items-center gap-3 md:gap-4">
                  {contact.icon}
                  <div>
                    <h3 className="font-semibold">{contact.title}</h3>
                    <p className="text-muted-foreground break-all text-sm md:text-base">{contact.value}</p>
                  </div>
                </div>
              </div>
            ))}

            <div className="rounded-lg border bg-card p-4">
              <Button asChild className="w-full" variant="default">
                <a href="https://t.me/your_telegram_username" target="_blank" rel="noopener noreferrer">
                  <BrandTelegram className="mr-2 h-5 w-5" /> Написать в Telegram
                </a>
              </Button>
            </div>
          </div>
        </div>

        <div className="order-1 md:order-2">
          <div className="space-y-4 md:space-y-6">
            <h2 className="text-xl md:text-2xl font-semibold">Отправить сообщение</h2>
            <div className="rounded-lg border bg-card p-4 md:p-6">
              <form className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium">
                    Имя
                  </label>
                  <input
                    id="name"
                    placeholder="Введите ваше имя"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium">
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    placeholder="Введите ваш email"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Сообщение
                  </label>
                  <textarea
                    id="message"
                    placeholder="Введите ваше сообщение"
                    rows={4}
                    className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  />
                </div>

                <Button type="submit" className="w-full">
                  <Send className="mr-2 h-4 w-4" /> Отправить сообщение
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
