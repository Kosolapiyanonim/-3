"use client"

import { useEffect, useRef, useState } from "react"
import gsap from "gsap"
import { GsapTextReveal } from "@/components/gsap/text-reveal"
import { ProjectCard } from "@/components/project-card"

export default function ProjectsPage() {
  const [filter, setFilter] = useState<string>("all")
  const projectsRef = useRef<HTMLDivElement>(null)
  const filtersRef = useRef<HTMLDivElement>(null)

  const projects = [
    {
      id: 1,
      title: "Веб-приложение для управления проектами",
      description:
        "Разработка полнофункционального веб-приложения для управления проектами с использованием React и Node.js.",
      image: "/placeholder.svg?height=200&width=400",
      tags: ["React", "Node.js", "MongoDB"],
      category: "web",
    },
    {
      id: 2,
      title: "Мобильное приложение для фитнеса",
      description:
        "Создание мобильного приложения для отслеживания тренировок и питания с использованием React Native.",
      image: "/placeholder.svg?height=200&width=400",
      tags: ["React Native", "Firebase", "Redux"],
      category: "mobile",
    },
    {
      id: 3,
      title: "Корпоративный сайт для компании",
      description:
        "Разработка современного корпоративного сайта с адаптивным дизайном и системой управления контентом.",
      image: "/placeholder.svg?height=200&width=400",
      tags: ["Next.js", "Tailwind CSS", "Strapi"],
      category: "web",
    },
    {
      id: 4,
      title: "Дизайн интерфейса для банковского приложения",
      description: "Создание современного и удобного интерфейса для мобильного банковского приложения.",
      image: "/placeholder.svg?height=200&width=400",
      tags: ["Figma", "UI/UX", "Prototyping"],
      category: "design",
    },
    {
      id: 5,
      title: "E-commerce платформа",
      description: "Разработка полнофункциональной платформы электронной коммерции с интеграцией платежных систем.",
      image: "/placeholder.svg?height=200&width=400",
      tags: ["React", "Node.js", "Stripe", "MongoDB"],
      category: "web",
    },
    {
      id: 6,
      title: "Приложение для доставки еды",
      description: "Мобильное приложение для заказа и доставки еды с функцией отслеживания заказа в реальном времени.",
      image: "/placeholder.svg?height=200&width=400",
      tags: ["Flutter", "Firebase", "Google Maps API"],
      category: "mobile",
    },
  ]

  const filteredProjects = filter === "all" ? projects : projects.filter((project) => project.category === filter)

  useEffect(() => {
    // Анимация для фильтров
    if (filtersRef.current) {
      gsap.from(filtersRef.current.children, {
        opacity: 0,
        y: -20,
        stagger: 0.1,
        duration: 0.5,
        ease: "power2.out",
      })
    }

    // Анимация для проектов при первой загрузке
    if (projectsRef.current) {
      gsap.from(projectsRef.current.children, {
        opacity: 0,
        y: 50,
        stagger: 0.1,
        duration: 0.6,
        ease: "power3.out",
        scrollTrigger: {
          trigger: projectsRef.current,
          start: "top bottom-=100",
          toggleActions: "play none none none",
        },
      })
    }
  }, [])

  // Анимация при изменении фильтра
  useEffect(() => {
    if (projectsRef.current) {
      // Сначала скрываем все элементы
      gsap.to(projectsRef.current.children, {
        opacity: 0,
        y: 20,
        stagger: 0.05,
        duration: 0.3,
        ease: "power2.in",
        onComplete: () => {
          // Затем показываем отфильтрованные элементы
          gsap.to(projectsRef.current?.children, {
            opacity: 1,
            y: 0,
            stagger: 0.1,
            duration: 0.5,
            ease: "power3.out",
          })
        },
      })
    }
  }, [filter])

  return (
    <div className="space-y-6 md:space-y-8 w-full">
      <section className="space-y-2 md:space-y-4">
        <GsapTextReveal className="text-2xl md:text-3xl lg:text-4xl font-bold">Проекты</GsapTextReveal>
        <p className="text-sm md:text-base lg:text-xl text-muted-foreground">
          Ознакомьтесь с моими последними работами в различных областях разработки.
        </p>
      </section>

      <div ref={filtersRef} className="flex flex-wrap gap-2 mb-6">
        <button
          onClick={() => setFilter("all")}
          className={`px-4 py-2 rounded-md text-sm transition-all ${
            filter === "all"
              ? "bg-primary text-primary-foreground"
              : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
          }`}
        >
          Все
        </button>
        <button
          onClick={() => setFilter("web")}
          className={`px-4 py-2 rounded-md text-sm transition-all ${
            filter === "web"
              ? "bg-primary text-primary-foreground"
              : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
          }`}
        >
          Веб
        </button>
        <button
          onClick={() => setFilter("mobile")}
          className={`px-4 py-2 rounded-md text-sm transition-all ${
            filter === "mobile"
              ? "bg-primary text-primary-foreground"
              : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
          }`}
        >
          Мобильные
        </button>
        <button
          onClick={() => setFilter("design")}
          className={`px-4 py-2 rounded-md text-sm transition-all ${
            filter === "design"
              ? "bg-primary text-primary-foreground"
              : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
          }`}
        >
          Дизайн
        </button>
      </div>

      <div ref={projectsRef} className="grid grid-cols-1 gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredProjects.map((project) => (
          <div key={project.id} className="opacity-0">
            <ProjectCard project={project} />
          </div>
        ))}
      </div>
    </div>
  )
}
