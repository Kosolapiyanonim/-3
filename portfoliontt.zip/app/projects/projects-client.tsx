"use client"

import { SwipeContainer } from "@/components/swipe-container"
import type { ReactNode } from "react"

interface ProjectsClientProps {
  children: ReactNode
}

export function ProjectsClient({ children }: ProjectsClientProps) {
  return (
    <SwipeContainer
      className="w-full"
      onSwipeLeft={() => console.log("Swiped left")}
      onSwipeRight={() => console.log("Swiped right")}
    >
      {children}
    </SwipeContainer>
  )
}
