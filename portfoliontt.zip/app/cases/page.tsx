"use client"

import { useEffect, useRef, useState } from "react"
import gsap from "gsap"
import { GsapTextReveal } from "@/components/gsap/text-reveal"
import { CaseCard } from "@/components/case-card"
import type { CaseStudy } from "@/types/database"

export default function CasesPage() {
  const [cases, setCases] = useState<CaseStudy[]>([])
  const [allTags, setAllTags] = useState<string[]>([])
  const [selectedTag, setSelectedTag] = useState<string>("all")
  const casesRef = useRef<HTMLDivElement>(null)
  const filtersRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Загрузка кейсов
    fetch("/api/cases")
      .then((res) => res.json())
      .then((data) => {
        setCases(data)

        // Извлечение всех уникальных тегов
        const tags = new Set<string>()
        data.forEach((caseStudy: CaseStudy) => {
          caseStudy.tags.forEach((tag) => tags.add(tag))
        })
        setAllTags(Array.from(tags))
      })
      .catch((err) => console.error("Error loading cases:", err))

    // Анимация для фильтров
    if (filtersRef.current) {
      gsap.from(filtersRef.current.children, {
        opacity: 0,
        y: -20,
        stagger: 0.1,
        duration: 0.5,
        ease: "power2.out",
      })
    }
  }, [])

  // Анимация при изменении фильтра
  useEffect(() => {
    if (casesRef.current) {
      // Сначала скрываем все элементы
      gsap.to(casesRef.current.children, {
        opacity: 0,
        y: 20,
        stagger: 0.05,
        duration: 0.3,
        ease: "power2.in",
        onComplete: () => {
          // Затем показываем отфильтрованные элементы
          gsap.to(casesRef.current?.children, {
            opacity: 1,
            y: 0,
            stagger: 0.1,
            duration: 0.5,
            ease: "power3.out",
          })
        },
      })
    }
  }, [selectedTag])

  // Фильтрация кейсов
  const filteredCases = cases.filter((caseStudy) => {
    return selectedTag === "all" || caseStudy.tags.includes(selectedTag)
  })

  // Если данные еще не загружены, показываем заглушки
  const placeholderCases: CaseStudy[] = cases.length
    ? filteredCases
    : [
        {
          id: 1,
          title: "Редизайн интернет-магазина",
          slug: "ecommerce-redesign",
          description: "Полный редизайн интернет-магазина с увеличением конверсии на 35%",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["UX/UI", "E-commerce", "Conversion"],
          results: "Увеличение конверсии на 35%, рост среднего чека на 20%",
          created_at: "",
          updated_at: "",
        },
        {
          id: 2,
          title: "Оптимизация воронки продаж",
          slug: "sales-funnel-optimization",
          description: "Анализ и оптимизация воронки продаж для B2B SaaS-продукта",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["SaaS", "B2B", "Analytics"],
          results: "Увеличение конверсии из лида в клиента на 25%",
          created_at: "",
          updated_at: "",
        },
        {
          id: 3,
          title: "Запуск мобильного приложения",
          slug: "mobile-app-launch",
          description: "Стратегия и реализация запуска мобильного приложения для стартапа",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["Mobile", "Marketing", "Startup"],
          results: "10,000+ установок в первый месяц, рейтинг 4.8/5",
          created_at: "",
          updated_at: "",
        },
      ]

  return (
    <div className="space-y-6 md:space-y-8 w-full">
      <section className="space-y-2 md:space-y-4">
        <GsapTextReveal className="text-2xl md:text-3xl lg:text-4xl font-bold">Кейсы</GsapTextReveal>
        <p className="text-sm md:text-base lg:text-xl text-muted-foreground">
          Изучите мои успешные кейсы и результаты работы с клиентами.
        </p>
      </section>

      {allTags.length > 0 && (
        <div ref={filtersRef} className="flex flex-wrap gap-2 mb-6">
          <button
            onClick={() => setSelectedTag("all")}
            className={`px-4 py-2 rounded-md text-sm transition-all ${
              selectedTag === "all"
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
            }`}
          >
            Все теги
          </button>
          {allTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`px-4 py-2 rounded-md text-sm transition-all ${
                selectedTag === tag
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      )}

      <div ref={casesRef} className="grid grid-cols-1 gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-3">
        {placeholderCases.map((caseStudy) => (
          <div key={caseStudy.id} className="opacity-0">
            <CaseCard caseStudy={caseStudy} />
          </div>
        ))}
      </div>
    </div>
  )
}
