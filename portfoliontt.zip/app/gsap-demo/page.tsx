"use client"

import { useEffect } from "react"
import { GsapScrollTrigger, GsapParallax, GsapTextReveal, GsapHorizontalScroll } from "@/components/gsap"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import GsapLayout from "../gsap-layout"
import Link from "next/link"

export default function GsapDemoPage() {
  // Load GSAP and its plugins
  useEffect(() => {
    // This is just to ensure GSAP is loaded
    const loadGsap = async () => {
      try {
        const gsap = (await import("gsap")).default
        const ScrollTrigger = (await import("gsap/ScrollTrigger")).default
        const ScrollSmoother = (await import("gsap/ScrollSmoother")).default

        gsap.registerPlugin(ScrollTrigger, ScrollSmoother)
      } catch (error) {
        console.error("Error loading GSAP:", error)
      }
    }

    loadGsap()
  }, [])

  return (
    <GsapLayout>
      <div className="min-h-screen">
        <section className="py-20 px-4 md:px-8 text-center">
          <GsapTextReveal>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">GSAP Animation Demo</h1>
          </GsapTextReveal>

          <GsapScrollTrigger animation="fade" delay={0.3}>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8">
              Scroll down to see various GSAP animations in action
            </p>
          </GsapScrollTrigger>

          <GsapScrollTrigger animation="scale" delay={0.6}>
            <div className="flex justify-center">
              <Button asChild size="lg">
                <Link href="/">Back to Home</Link>
              </Button>
            </div>
          </GsapScrollTrigger>
        </section>

        <section className="py-20 px-4 md:px-8 bg-muted">
          <GsapScrollTrigger animation="slide">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Fade In Animations</h2>
          </GsapScrollTrigger>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {[1, 2, 3].map((item) => (
              <GsapScrollTrigger key={item} animation="fade" delay={item * 0.2}>
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold mb-2">Card {item}</h3>
                    <p>This card fades in with a slight delay based on its position.</p>
                  </CardContent>
                </Card>
              </GsapScrollTrigger>
            ))}
          </div>
        </section>

        <section className="py-20 px-4 md:px-8">
          <GsapTextReveal>
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Text Reveal Animation</h2>
          </GsapTextReveal>

          <GsapTextReveal className="max-w-3xl mx-auto text-xl text-center">
            <p>
              This text is revealed character by character as you scroll down the page. It creates an engaging effect
              that draws attention to important content.
            </p>
          </GsapTextReveal>
        </section>

        <section className="py-20 px-4 md:px-8 bg-muted relative overflow-hidden">
          <GsapParallax speed={-0.2} className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-gradient-to-b from-primary/10 to-transparent opacity-50"></div>
          </GsapParallax>

          <div className="relative z-10">
            <GsapScrollTrigger animation="fade">
              <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Parallax Effects</h2>
            </GsapScrollTrigger>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <GsapParallax speed={0.3}>
                <Card className="h-64 flex items-center justify-center">
                  <CardContent>
                    <h3 className="text-xl font-semibold">Parallax Slow</h3>
                  </CardContent>
                </Card>
              </GsapParallax>

              <GsapParallax speed={0.6}>
                <Card className="h-64 flex items-center justify-center">
                  <CardContent>
                    <h3 className="text-xl font-semibold">Parallax Fast</h3>
                  </CardContent>
                </Card>
              </GsapParallax>
            </div>
          </div>
        </section>

        <section className="py-20">
          <GsapScrollTrigger animation="fade">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Horizontal Scroll</h2>
          </GsapScrollTrigger>

          <GsapHorizontalScroll className="h-[50vh]" containerClassName="gap-4 px-4 md:px-8">
            {[1, 2, 3, 4, 5].map((item) => (
              <Card key={item} className="min-w-[300px] md:min-w-[400px] h-full flex items-center justify-center">
                <CardContent>
                  <h3 className="text-xl font-semibold">Panel {item}</h3>
                </CardContent>
              </Card>
            ))}
          </GsapHorizontalScroll>
        </section>

        <section className="py-20 px-4 md:px-8 text-center">
          <GsapScrollTrigger animation="scale">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">That's it!</h2>
          </GsapScrollTrigger>

          <GsapScrollTrigger animation="fade" delay={0.3}>
            <p className="text-xl text-muted-foreground mb-8">
              You've seen some of the animations possible with GSAP and ScrollTrigger
            </p>
          </GsapScrollTrigger>

          <GsapScrollTrigger animation="slide" delay={0.6}>
            <div className="flex justify-center">
              <Button asChild size="lg">
                <Link href="/">Back to Home</Link>
              </Button>
            </div>
          </GsapScrollTrigger>
        </section>
      </div>
    </GsapLayout>
  )
}
