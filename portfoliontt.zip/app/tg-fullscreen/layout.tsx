import type React from "react"
import { Inter } from "next/font/google"
import "../globals.css"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin", "cyrillic"] })

export const metadata = {
  title: "Портфолио NTT - Telegram Fullscreen",
  description: "Версия портфолио для Telegram WebApp с принудительным полноэкранным режимом",
}

export default function TelegramFullscreenLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: light)" />
        <meta name="theme-color" content="#1e1e1e" media="(prefers-color-scheme: dark)" />

        {/* Скрипт Telegram WebApp */}
        <script src="https://telegram.org/js/telegram-web-app.js"></script>
      </head>
      <body
        className={inter.className}
        style={{ margin: 0, padding: 0, overflow: "hidden", height: "100vh", width: "100vw" }}
      >
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <main className="h-full w-full overflow-auto">{children}</main>
        </ThemeProvider>

        {/* Инлайн-скрипт для расширения окна - САМЫЙ ВАЖНЫЙ ЭЛЕМЕНТ */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
          // Функция для расширения окна
          function expandTelegramWebApp() {
            if (window.Telegram && window.Telegram.WebApp) {
              console.log("Telegram WebApp найден, расширяем окно...");
              window.Telegram.WebApp.ready();
              window.Telegram.WebApp.expand();
              console.log("Окно расширено:", window.Telegram.WebApp.isExpanded);
              
              // Адаптация темы
              const colorScheme = window.Telegram.WebApp.colorScheme;
              document.documentElement.setAttribute('data-theme', colorScheme);
              
              return true;
            }
            return false;
          }
          
          // Пытаемся расширить окно сразу
          expandTelegramWebApp();
          
          // Пытаемся расширить окно после загрузки DOM
          document.addEventListener('DOMContentLoaded', expandTelegramWebApp);
          
          // Пытаемся расширить окно после полной загрузки страницы
          window.addEventListener('load', expandTelegramWebApp);
          
          // Дополнительные попытки через интервалы
          let attempts = 0;
          const maxAttempts = 10;
          const interval = setInterval(() => {
            attempts++;
            console.log("Попытка расширения окна:", attempts);
            
            if (expandTelegramWebApp() || attempts >= maxAttempts) {
              clearInterval(interval);
            }
          }, 300);
        `,
          }}
        />
      </body>
    </html>
  )
}
