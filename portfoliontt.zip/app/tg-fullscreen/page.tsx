export default function TelegramFullscreenPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <h1 className="text-2xl font-bold mb-4">Портфолио NTT в Telegram</h1>
      <p className="mb-6 text-center">Эта страница должна открыться на полный экран</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-md">
        <a
          href="/tg/projects"
          className="bg-primary text-primary-foreground p-4 rounded-lg text-center font-medium hover:opacity-90 transition-opacity"
        >
          Проекты
        </a>
        <a
          href="/tg/about"
          className="bg-primary text-primary-foreground p-4 rounded-lg text-center font-medium hover:opacity-90 transition-opacity"
        >
          Обо мне
        </a>
        <a
          href="/tg/contact"
          className="bg-primary text-primary-foreground p-4 rounded-lg text-center font-medium hover:opacity-90 transition-opacity"
        >
          Контакты
        </a>
        <a
          href="/tg/debug"
          className="bg-secondary text-secondary-foreground p-4 rounded-lg text-center font-medium hover:opacity-90 transition-opacity"
        >
          Отладка
        </a>
      </div>
    </div>
  )
}
