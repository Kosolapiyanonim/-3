"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { useEffect, useRef, useState } from "react"
import gsap from "gsap"
import { GsapTextReveal } from "@/components/gsap/text-reveal"
import { GsapParallax } from "@/components/gsap/parallax"
import { ProjectCard } from "@/components/project-card"
import { CaseCard } from "@/components/case-card"
import { FancyCasinoButton } from "@/components/fancy-casino-button"
import type { Project, CaseStudy } from "@/types/database"

export default function Home() {
  const [projects, setProjects] = useState<Project[]>([])
  const [cases, setCases] = useState<CaseStudy[]>([])
  const projectsRef = useRef<HTMLDivElement>(null)
  const casesRef = useRef<HTMLDivElement>(null)
  const buttonsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Загрузка проектов
    fetch("/api/projects?limit=3")
      .then((res) => res.json())
      .then((data) => setProjects(data))
      .catch((err) => console.error("Error loading projects:", err))

    // Загрузка кейсов
    fetch("/api/cases?limit=3")
      .then((res) => res.json())
      .then((data) => setCases(data))
      .catch((err) => console.error("Error loading cases:", err))

    // Анимация для кнопок
    if (buttonsRef.current) {
      gsap.from(buttonsRef.current.children, {
        opacity: 0,
        y: 20,
        stagger: 0.2,
        duration: 0.8,
        ease: "power3.out",
        delay: 0.8,
      })
    }

    // Анимация для проектов
    if (projectsRef.current) {
      gsap.from(projectsRef.current.children, {
        opacity: 0,
        y: 50,
        stagger: 0.2,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: projectsRef.current,
          start: "top bottom-=100",
          toggleActions: "play none none none",
        },
      })
    }

    // Анимация для кейсов
    if (casesRef.current) {
      gsap.from(casesRef.current.children, {
        opacity: 0,
        y: 50,
        stagger: 0.2,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: casesRef.current,
          start: "top bottom-=100",
          toggleActions: "play none none none",
        },
      })
    }
  }, [])

  // Если данные еще не загружены, показываем заглушки
  const placeholderProjects: Project[] = projects.length
    ? projects
    : [
        {
          id: 1,
          title: "Веб-приложение для управления проектами",
          slug: "project-management-app",
          description:
            "Разработка полнофункционального веб-приложения для управления проектами с использованием React и Node.js.",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["React", "Node.js", "MongoDB"],
          category: "web",
          created_at: "",
          updated_at: "",
        },
        {
          id: 2,
          title: "Мобильное приложение для фитнеса",
          slug: "fitness-mobile-app",
          description:
            "Создание мобильного приложения для отслеживания тренировок и питания с использованием React Native.",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["React Native", "Firebase", "Redux"],
          category: "mobile",
          created_at: "",
          updated_at: "",
        },
        {
          id: 3,
          title: "Корпоративный сайт для компании",
          slug: "corporate-website",
          description:
            "Разработка современного корпоративного сайта с адаптивным дизайном и системой управления контентом.",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["Next.js", "Tailwind CSS", "Strapi"],
          category: "web",
          created_at: "",
          updated_at: "",
        },
      ]

  const placeholderCases: CaseStudy[] = cases.length
    ? cases
    : [
        {
          id: 1,
          title: "Редизайн интернет-магазина",
          slug: "ecommerce-redesign",
          description: "Полный редизайн интернет-магазина с увеличением конверсии на 35%",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["UX/UI", "E-commerce", "Conversion"],
          results: "Увеличение конверсии на 35%, рост среднего чека на 20%",
          created_at: "",
          updated_at: "",
        },
        {
          id: 2,
          title: "Оптимизация воронки продаж",
          slug: "sales-funnel-optimization",
          description: "Анализ и оптимизация воронки продаж для B2B SaaS-продукта",
          content: "",
          image_url: "/placeholder.svg?height=200&width=400",
          tags: ["SaaS", "B2B", "Analytics"],
          results: "Увеличение конверсии из лида в клиента на 25%",
          created_at: "",
          updated_at: "",
        },
      ]

  return (
    <div className="space-y-8 md:space-y-16 w-full">
      <section className="space-y-4 md:space-y-6">
        <GsapTextReveal className="text-2xl md:text-4xl font-bold">Добро пожаловать в моё портфолио</GsapTextReveal>
        <GsapParallax speed={0.2} className="text-base md:text-xl text-muted-foreground">
          Я специализируюсь на разработке современных веб-приложений и сайтов, используя передовые технологии.
        </GsapParallax>
        <div ref={buttonsRef} className="flex flex-col sm:flex-row flex-wrap gap-3">
          <Button asChild className="w-full sm:w-auto">
            <Link href="/contact">Связаться со мной</Link>
          </Button>
          <Button variant="outline" asChild className="w-full sm:w-auto">
            <Link href="/portfolio">
              Смотреть портфолио <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button
            variant="outline"
            asChild
            className="w-full sm:w-auto bg-yellow-600 hover:bg-yellow-500 text-white border-yellow-700 hover:border-yellow-600"
          >
            <Link href="/casino">
              Сыграть в казино <span className="ml-2">🎰</span>
            </Link>
          </Button>
        </div>
      </section>

      <section className="space-y-4 md:space-y-8">
        <GsapTextReveal className="text-xl md:text-2xl font-semibold">Последние проекты</GsapTextReveal>
        <div ref={projectsRef} className="grid grid-cols-1 gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-3">
          {placeholderProjects.map((project, index) => (
            <div key={project.id} data-speed={0.1 * (index + 1)}>
              <ProjectCard project={project} />
            </div>
          ))}
        </div>
        <div className="flex justify-center mt-4">
          <Button asChild variant="outline">
            <Link href="/portfolio">
              Все проекты <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <section className="space-y-4 md:space-y-8">
        <GsapTextReveal className="text-xl md:text-2xl font-semibold">Кейсы</GsapTextReveal>
        <div ref={casesRef} className="grid grid-cols-1 gap-4 sm:gap-6 md:grid-cols-2 lg:grid-cols-3">
          {placeholderCases.map((caseStudy, index) => (
            <div key={caseStudy.id} data-speed={0.1 * (index + 1)}>
              <CaseCard caseStudy={caseStudy} />
            </div>
          ))}
        </div>
        <div className="flex justify-center mt-4">
          <Button asChild variant="outline">
            <Link href="/cases">
              Все кейсы <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Добавляем кнопку казино */}
      <FancyCasinoButton />
    </div>
  )
}
