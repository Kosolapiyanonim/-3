import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { PortfolioSidebar } from "@/components/portfolio-sidebar"
import Script from "next/script"
import { HomeButtonProvider } from "@/components/home-button-provider"
import { TelegramWebAppHandler } from "@/components/telegram-web-app-handler"
import { PageTransition } from "@/components/page-transition"

const inter = Inter({ subsets: ["latin", "cyrillic"] })

export const metadata: Metadata = {
  title: "Портфолио NTT",
  description: "Профессиональное портфолио NTT",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: light)" />
        <meta name="theme-color" content="#1e1e1e" media="(prefers-color-scheme: dark)" />
        {/* Скрипт Telegram WebApp */}
        <Script src="https://telegram.org/js/telegram-web-app.js" strategy="beforeInteractive" />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <div className="flex min-h-screen flex-col md:flex-row">
            <PortfolioSidebar />
            <main className="flex-1 p-4 md:p-8 w-full md:w-auto relative">
              <PageTransition>{children}</PageTransition>
            </main>
          </div>
          <HomeButtonProvider />
          <TelegramWebAppHandler />
        </ThemeProvider>

        {/* Инлайн-скрипт для расширения окна */}
        <Script id="telegram-webapp" strategy="afterInteractive">
          {`
            document.addEventListener('DOMContentLoaded', function() {
              if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.ready();
                window.Telegram.WebApp.expand();
                console.log("Telegram WebApp активирован после загрузки DOM");
              }
            });
            
            // Дополнительная попытка через таймаут
            setTimeout(function() {
              if (window.Telegram && window.Telegram.WebApp) {
                window.Telegram.WebApp.ready();
                window.Telegram.WebApp.expand();
                console.log("Telegram WebApp активирован через таймаут");
              }
            }, 1000);
          `}
        </Script>
      </body>
    </html>
  )
}
