"use client"

import { GsapTextReveal } from "@/components/gsap/text-reveal"
import { GsapParallax } from "@/components/gsap/parallax"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Check, ArrowRight } from "lucide-react"
import Link from "next/link"
import { useEffect, useRef } from "react"
import gsap from "gsap"

export default function ForAdminsPage() {
  const sectionsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (sectionsRef.current) {
      gsap.from(sectionsRef.current.children, {
        opacity: 0,
        y: 50,
        stagger: 0.3,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: sectionsRef.current,
          start: "top bottom-=100",
          toggleActions: "play none none none",
        },
      })
    }
  }, [])

  return (
    <div className="space-y-8 md:space-y-16 w-full">
      <section className="space-y-4 md:space-y-6">
        <GsapTextReveal className="text-2xl md:text-4xl font-bold">Админам</GsapTextReveal>
        <GsapParallax speed={0.2} className="text-base md:text-xl text-muted-foreground">
          Информация для администраторов сообществ и владельцев телеграм-каналов.
        </GsapParallax>
      </section>

      <div ref={sectionsRef} className="space-y-8">
        <section className="space-y-4">
          <h2 className="text-xl md:text-2xl font-semibold">Что я предлагаю</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="transform-gpu hover:scale-105 transition-transform duration-300">
              <CardContent className="p-6">
                <h3 className="font-semibold text-lg mb-4">Разработка ботов</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Автоматизация процессов</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Интеграция с внешними сервисами</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Аналитика и статистика</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="transform-gpu hover:scale-105 transition-transform duration-300">
              <CardContent className="p-6">
                <h3 className="font-semibold text-lg mb-4">Telegram WebApps</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Интерактивные приложения</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Интеграция с ботами</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Кастомный дизайн</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="transform-gpu hover:scale-105 transition-transform duration-300">
              <CardContent className="p-6">
                <h3 className="font-semibold text-lg mb-4">Консультации</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Стратегия развития канала</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Оптимизация процессов</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span>Технические решения</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl md:text-2xl font-semibold">Преимущества сотрудничества</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Индивидуальный подход</h3>
                  <p className="text-muted-foreground">Решения, адаптированные под ваши конкретные задачи</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Опыт работы с Telegram</h3>
                  <p className="text-muted-foreground">Глубокое понимание экосистемы Telegram</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Техническая поддержка</h3>
                  <p className="text-muted-foreground">Оперативное решение возникающих вопросов</p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Современные технологии</h3>
                  <p className="text-muted-foreground">Использование передовых инструментов разработки</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Масштабируемые решения</h3>
                  <p className="text-muted-foreground">Возможность расширения функционала в будущем</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-primary/20 p-2 rounded-full">
                  <Check className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Прозрачное ценообразование</h3>
                  <p className="text-muted-foreground">Четкое понимание стоимости работ</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="space-y-4 bg-secondary/30 p-6 rounded-lg">
          <h2 className="text-xl md:text-2xl font-semibold">Примеры проектов</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Бот для управления подписками</h3>
              <p className="text-muted-foreground">
                Автоматизация процесса подписки, оплаты и доступа к контенту для канала с 50,000+ подписчиков.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">WebApp для образовательной платформы</h3>
              <p className="text-muted-foreground">
                Интерактивное приложение с курсами, тестами и отслеживанием прогресса для образовательного проекта.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Система аналитики для сети каналов</h3>
              <p className="text-muted-foreground">
                Комплексное решение для сбора и анализа статистики по нескольким связанным каналам и чатам.
              </p>
            </div>
          </div>
        </section>

        <div className="flex justify-center mt-8">
          <Button asChild size="lg">
            <Link href="/contact">
              Обсудить проект <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
