import type React from "react"
import { Inter } from "next/font/google"
import "../globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Script from "next/script"

const inter = Inter({ subsets: ["latin", "cyrillic"] })

export const metadata = {
  title: "Портфолио NTT - Telegram WebApp",
  description: "Версия портфолио для Telegram WebApp",
}

export default function TelegramWebAppLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: light)" />
        <meta name="theme-color" content="#1e1e1e" media="(prefers-color-scheme: dark)" />
      </head>
      <body
        className={inter.className}
        style={{ margin: 0, padding: 0, overflow: "hidden", height: "100vh", width: "100vw" }}
      >
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <main className="h-full w-full overflow-auto">{children}</main>
        </ThemeProvider>

        {/* Скрипт Telegram WebApp */}
        <Script src="https://telegram.org/js/telegram-web-app.js" strategy="beforeInteractive" />
      </body>
    </html>
  )
}
