"use client"

import { useEffect } from "react"
import Link from "next/link"

export default function TelegramWebAppPage() {
  useEffect(() => {
    // Функция для расширения окна
    function expandTelegramWebApp() {
      if (typeof window !== "undefined" && window.Telegram && window.Telegram.WebApp) {
        console.log("Telegram WebApp найден, расширяем окно...")
        window.Telegram.WebApp.ready()
        window.Telegram.WebApp.expand()
        console.log("Окно расширено:", window.Telegram.WebApp.isExpanded)
        return true
      }
      console.log("Telegram WebApp не найден")
      return false
    }

    // Пытаемся расширить окно сразу
    expandTelegramWebApp()

    // Дополнительные попытки через интервалы
    let attempts = 0
    const maxAttempts = 10
    const interval = setInterval(() => {
      attempts++
      console.log("Попытка расширения окна:", attempts)

      if (expandTelegramWebApp() || attempts >= maxAttempts) {
        clearInterval(interval)
        console.log("Завершены попытки расширения окна")
      }
    }, 300)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <h1 className="text-2xl font-bold mb-4">Портфолио NTT в Telegram</h1>
      <p className="mb-6 text-center">Эта страница оптимизирована для Telegram WebApp</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-md">
        <Link
          href="/projects"
          className="bg-primary text-primary-foreground p-4 rounded-lg text-center font-medium hover:opacity-90 transition-opacity"
        >
          Проекты
        </Link>
        <Link
          href="/about"
          className="bg-primary text-primary-foreground p-4 rounded-lg text-center font-medium hover:opacity-90 transition-opacity"
        >
          Обо мне
        </Link>
        <Link
          href="/contact"
          className="bg-primary text-primary-foreground p-4 rounded-lg text-center font-medium hover:opacity-90 transition-opacity"
        >
          Контакты
        </Link>
        <Link
          href="/tg/debug"
          className="bg-secondary text-secondary-foreground p-4 rounded-lg text-center font-medium hover:opacity-90 transition-opacity"
        >
          Отладка
        </Link>
      </div>
    </div>
  )
}
