"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TelegramPage() {
  const [telegramInfo, setTelegramInfo] = useState<{
    available: boolean
    expanded: boolean | null
    theme: string | null
  }>({
    available: false,
    expanded: null,
    theme: null,
  })

  useEffect(() => {
    // Проверяем доступность Telegram WebApp
    if (typeof window !== "undefined" && window.Telegram && window.Telegram.WebApp) {
      setTelegramInfo({
        available: true,
        expanded: window.Telegram.WebApp.isExpanded,
        theme: window.Telegram.WebApp.colorScheme,
      })
    }
  }, [])

  const handleExpand = () => {
    if (typeof window !== "undefined" && window.Telegram && window.Telegram.WebApp) {
      window.Telegram.WebApp.expand()
      setTelegramInfo((prev) => ({
        ...prev,
        expanded: window.Telegram.WebApp.isExpanded,
      }))
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Тест Telegram WebApp</h1>

      <Card>
        <CardHeader>
          <CardTitle>Статус Telegram WebApp</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p>
              <strong>Доступен:</strong> {telegramInfo.available ? "Да" : "Нет"}
            </p>
            {telegramInfo.available && (
              <>
                <p>
                  <strong>Развернут:</strong> {telegramInfo.expanded ? "Да" : "Нет"}
                </p>
                <p>
                  <strong>Тема:</strong> {telegramInfo.theme || "Не определена"}
                </p>
              </>
            )}
          </div>

          <Button onClick={handleExpand} disabled={!telegramInfo.available}>
            Развернуть вручную
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
