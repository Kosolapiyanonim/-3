"use client"

import { GsapTextReveal } from "@/components/gsap/text-reveal"
import { GsapParallax } from "@/components/gsap/parallax"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { Check, ArrowRight } from "lucide-react"
import Link from "next/link"
import { useEffect, useRef } from "react"
import gsap from "gsap"

export default function EarnWithMePage() {
  const cardsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (cardsRef.current) {
      gsap.from(cardsRef.current.children, {
        opacity: 0,
        y: 50,
        stagger: 0.2,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: {
          trigger: cardsRef.current,
          start: "top bottom-=100",
          toggleActions: "play none none none",
        },
      })
    }
  }, [])

  return (
    <div className="space-y-8 md:space-y-16 w-full">
      <section className="space-y-4 md:space-y-6">
        <GsapTextReveal className="text-2xl md:text-4xl font-bold">Заработай со мной</GsapTextReveal>
        <GsapParallax speed={0.2} className="text-base md:text-xl text-muted-foreground">
          Присоединяйтесь к моей команде и получайте вознаграждение за сотрудничество. Выберите подходящий вам формат
          работы.
        </GsapParallax>
      </section>

      <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="transform-gpu hover:scale-105 transition-transform duration-300">
          <CardHeader>
            <CardTitle>Партнерская программа</CardTitle>
            <CardDescription>Рекомендуйте мои услуги и получайте комиссию</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Комиссия 10% от стоимости проекта</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Выплаты после успешного завершения проекта</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Персональная реферальная ссылка</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Доступ к маркетинговым материалам</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full">
              <Link href="/contact">
                Стать партнером <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="transform-gpu hover:scale-105 transition-transform duration-300">
          <CardHeader>
            <CardTitle>Фриланс-сотрудничество</CardTitle>
            <CardDescription>Работайте над проектами в моей команде</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Гибкий график работы</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Оплата за выполненные задачи</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Интересные проекты</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Возможность профессионального роста</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full">
              <Link href="/for-performers">
                Подробнее <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="transform-gpu hover:scale-105 transition-transform duration-300">
          <CardHeader>
            <CardTitle>Совместные проекты</CardTitle>
            <CardDescription>Давайте создадим что-то вместе</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Разделение прибыли от проекта</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Совместное владение интеллектуальной собственностью</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Долгосрочное сотрудничество</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span>Возможность масштабирования</span>
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full">
              <Link href="/contact">
                Обсудить идею <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </div>

      <section className="space-y-4 md:space-y-6 bg-secondary/30 p-6 rounded-lg">
        <h2 className="text-xl md:text-2xl font-semibold">Часто задаваемые вопросы</h2>
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Как происходит оплата?</h3>
            <p className="text-muted-foreground">
              Оплата производится через безопасные платежные системы после выполнения работы или по этапам для крупных
              проектов.
            </p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Какие навыки требуются для сотрудничества?</h3>
            <p className="text-muted-foreground">
              В зависимости от проекта могут потребоваться различные навыки. Основные направления: веб-разработка,
              дизайн, маркетинг.
            </p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Как начать сотрудничество?</h3>
            <p className="text-muted-foreground">
              Свяжитесь со мной через форму на странице контактов, опишите ваш опыт и предпочтительный формат
              сотрудничества.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
