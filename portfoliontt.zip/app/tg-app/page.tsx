export default function TgAppPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <h1 className="text-2xl font-bold mb-4">Telegram WebApp</h1>
      <p className="mb-6">
        Эта страница предназначена для использования в Telegram WebApp. Пожалуйста, откройте ее через Telegram бота.
      </p>
      <div className="flex flex-col gap-4 w-full max-w-md">
        <a href="/api/webapp" className="bg-primary text-primary-foreground p-4 rounded-lg text-center font-medium">
          Открыть WebApp напрямую
        </a>
        <a href="/" className="bg-secondary text-secondary-foreground p-4 rounded-lg text-center font-medium">
          Вернуться на главную
        </a>
      </div>
    </div>
  )
}
