"use client"

import type { ReactNode } from "react"
import { GsapScrollSmoother } from "@/components/gsap"

interface GsapLayoutProps {
  children: ReactNode
}

export function GsapLayout({ children }: GsapLayoutProps) {
  return <GsapScrollSmoother>{children}</GsapScrollSmoother>
}

export default GsapLayout
