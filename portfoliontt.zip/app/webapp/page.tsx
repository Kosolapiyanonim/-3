"use client"

import { useEffect } from "react"

export default function WebAppRedirect() {
  useEffect(() => {
    // Перенаправляем на API-маршрут
    window.location.href = "/api/webapp"
  }, [])

  return (
    <div className="flex items-center justify-center min-h-screen">
      <p>Перенаправление...</p>
    </div>
  )
}
