"use client"

import { useEffect, useState } from "react"
import { GsapTextReveal } from "@/components/gsap/text-reveal"
import { GsapParallax } from "@/components/gsap/parallax"
import type { About } from "@/types/database"
import Image from "next/image"

export default function AboutPage() {
  const [about, setAbout] = useState<About | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch("/api/about")
      .then((res) => res.json())
      .then((data) => {
        setAbout(data)
        setLoading(false)
      })
      .catch((err) => {
        console.error("Error loading about data:", err)
        setLoading(false)
      })
  }, [])

  if (loading) {
    return (
      <div className="space-y-8 md:space-y-16 w-full animate-pulse">
        <div className="h-8 bg-gray-300 dark:bg-gray-700 rounded w-3/4 mb-4"></div>
        <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full mb-2"></div>
        <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-full mb-2"></div>
        <div className="h-4 bg-gray-300 dark:bg-gray-700 rounded w-5/6 mb-2"></div>
      </div>
    )
  }

  // Если данные не загрузились, показываем заглушку
  const aboutData = about || {
    id: 1,
    title: "Обо мне",
    content: `
      <p>Я профессиональный разработчик с более чем 5-летним опытом создания современных веб-приложений и сайтов.</p>
      <p>Моя специализация включает в себя разработку на React, Next.js, Node.js и других современных технологиях.</p>
      <p>Я стремлюсь создавать продукты, которые не только выглядят привлекательно, но и обеспечивают отличный пользовательский опыт и высокую производительность.</p>
    `,
    image_url: "/placeholder.svg?height=400&width=400",
    updated_at: "",
  }

  return (
    <div className="space-y-8 md:space-y-16 w-full">
      <section className="space-y-4 md:space-y-6">
        <GsapTextReveal className="text-2xl md:text-4xl font-bold">{aboutData.title}</GsapTextReveal>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          {aboutData.image_url && (
            <div className="relative h-64 md:h-80 w-full overflow-hidden rounded-lg">
              <Image
                src={aboutData.image_url || "/placeholder.svg"}
                alt={aboutData.title}
                fill
                className="object-cover"
              />
            </div>
          )}

          <GsapParallax speed={0.2} className="text-base md:text-lg text-muted-foreground">
            <div dangerouslySetInnerHTML={{ __html: aboutData.content }} />
          </GsapParallax>
        </div>
      </section>

      <section className="space-y-4 md:space-y-6">
        <GsapTextReveal className="text-xl md:text-2xl font-semibold">Навыки</GsapTextReveal>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          <div className="rounded-lg border bg-card p-4 md:p-6 transform-gpu hover:scale-105 transition-transform duration-300">
            <h3 className="font-semibold">Фронтенд</h3>
            <p className="mt-2 text-sm md:text-base">
              React, Next.js, Vue.js, Angular, HTML5, CSS3, JavaScript, TypeScript
            </p>
          </div>

          <div className="rounded-lg border bg-card p-4 md:p-6 transform-gpu hover:scale-105 transition-transform duration-300">
            <h3 className="font-semibold">Бэкенд</h3>
            <p className="mt-2 text-sm md:text-base">
              Node.js, Express, Django, Flask, PHP, MySQL, MongoDB, PostgreSQL
            </p>
          </div>

          <div className="rounded-lg border bg-card p-4 md:p-6 transform-gpu hover:scale-105 transition-transform duration-300">
            <h3 className="font-semibold">Инструменты</h3>
            <p className="mt-2 text-sm md:text-base">Git, Docker, AWS, Firebase, Vercel, Netlify, CI/CD</p>
          </div>
        </div>
      </section>
    </div>
  )
}
