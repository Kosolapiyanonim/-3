"use client"

import { useState, useEffect } from "react"

export function useTelegramWebApp() {
  const [isTelegramWebApp, setIsTelegramWebApp] = useState(false)
  const [telegramTheme, setTelegramTheme] = useState<string | null>(null)

  useEffect(() => {
    if (typeof window !== "undefined" && window.Telegram && window.Telegram.WebApp) {
      setIsTelegramWebApp(true)

      // Получаем тему из Telegram
      const colorScheme = window.Telegram.WebApp.colorScheme
      setTelegramTheme(colorScheme)
    }
  }, [])

  return { isTelegramWebApp, telegramTheme }
}
