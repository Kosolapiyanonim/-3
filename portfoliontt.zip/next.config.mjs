/** @type {import('next').NextConfig} */
const nextConfig = {
  // Игнорируем ошибки TypeScript и ESLint при сборке
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  // Настройка для изображений
  images: {
    domains: ['placeholder.svg'],
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
  },
  // Отключаем строгий режим для решения проблем с деплоем
  reactStrictMode: false,
  // Добавляем экспериментальные функции для поддержки серверных компонентов
  experimental: {
    serverActions: true,
  },
  // Добавляем настройку для решения проблем с peer dependencies
  modularizeImports: {
    'date-fns': {
      transform: 'date-fns/{{member}}',
    },
  }
}

export default nextConfig
