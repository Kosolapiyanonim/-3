"use client"

import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import { motion } from "framer-motion"
import { useEffect, useRef } from "react"
import gsap from "gsap"
import Link from "next/link"
import type { CaseStudy } from "@/types/database"

interface CaseCardProps {
  caseStudy: CaseStudy
}

export function CaseCard({ caseStudy }: CaseCardProps) {
  const cardRef = useRef<HTMLDivElement>(null)

  // Эффект наведения с GSAP
  useEffect(() => {
    if (!cardRef.current) return

    const card = cardRef.current

    const handleMouseMove = (e: MouseEvent) => {
      const { left, top, width, height } = card.getBoundingClientRect()
      const x = e.clientX - left
      const y = e.clientY - top

      const xPercent = x / width - 0.5
      const yPercent = y / height - 0.5

      gsap.to(card, {
        rotationY: xPercent * 10, // Поворот по оси Y
        rotationX: yPercent * -10, // Поворот по оси X
        transformPerspective: 1000,
        duration: 0.5,
        ease: "power2.out",
      })
    }

    const handleMouseLeave = () => {
      gsap.to(card, {
        rotationY: 0,
        rotationX: 0,
        duration: 0.5,
        ease: "power2.out",
      })
    }

    card.addEventListener("mousemove", handleMouseMove)
    card.addEventListener("mouseleave", handleMouseLeave)

    return () => {
      card.removeEventListener("mousemove", handleMouseMove)
      card.removeEventListener("mouseleave", handleMouseLeave)
    }
  }, [])

  return (
    <Link href={`/cases/${caseStudy.slug}`}>
      <Card ref={cardRef} className="overflow-hidden transition-all hover:shadow-md h-full transform-gpu">
        <div className="relative h-32 sm:h-40 w-full overflow-hidden">
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
            transition={{ duration: 0.3 }}
            className="h-full w-full"
          >
            <Image
              src={caseStudy.image_url || "/placeholder.svg"}
              alt={caseStudy.title}
              fill
              className="object-cover"
            />
          </motion.div>
        </div>
        <CardContent className="p-3 sm:p-4 md:p-6">
          <h3 className="mb-2 text-base sm:text-lg md:text-xl font-semibold line-clamp-2">{caseStudy.title}</h3>
          <p className="text-xs sm:text-sm md:text-base text-muted-foreground line-clamp-3">{caseStudy.description}</p>
        </CardContent>
        <CardFooter className="flex flex-wrap gap-1 sm:gap-2 p-3 sm:p-4 md:p-6 pt-0">
          {caseStudy.tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
        </CardFooter>
      </Card>
    </Link>
  )
}
