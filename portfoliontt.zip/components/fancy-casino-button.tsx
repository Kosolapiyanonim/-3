"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import Image from "next/image"

export function FancyCasinoButton() {
  const router = useRouter()
  const [isHovered, setIsHovered] = useState(false)
  const [isClicked, setIsClicked] = useState(false)

  const handleClick = () => {
    setIsClicked(true)
    setTimeout(() => {
      router.push("/casino")
    }, 300)
  }

  return (
    <motion.div
      className="fixed bottom-6 right-6 z-50"
      initial={{ opacity: 0, scale: 0, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ delay: 1, type: "spring", stiffness: 200, damping: 15 }}
    >
      <motion.button
        className="relative flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-lg border-2 border-indigo-300 overflow-hidden"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={handleClick}
        whileHover={{ scale: 1.1, boxShadow: "0 0 20px rgba(79, 70, 229, 0.6)" }}
        whileTap={{ scale: 0.95 }}
        animate={isClicked ? { scale: 0, opacity: 0 } : {}}
      >
        {/* Пульсирующий фон */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full"
          initial={{ scale: 0, opacity: 0 }}
          animate={{
            scale: isHovered ? [1, 1.2, 1] : 0,
            opacity: isHovered ? [0.7, 0, 0.7] : 0,
          }}
          transition={{
            duration: 1.5,
            repeat: Number.POSITIVE_INFINITY,
            repeatType: "reverse",
          }}
        />

        {/* Частицы */}
        {isHovered && (
          <>
            <motion.div
              className="absolute w-2 h-2 rounded-full bg-yellow-300"
              initial={{ x: 0, y: 0, opacity: 1 }}
              animate={{ x: -20, y: -20, opacity: 0 }}
              transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
            />
            <motion.div
              className="absolute w-2 h-2 rounded-full bg-yellow-300"
              initial={{ x: 0, y: 0, opacity: 1 }}
              animate={{ x: 20, y: -20, opacity: 0 }}
              transition={{ duration: 1, delay: 0.2, repeat: Number.POSITIVE_INFINITY }}
            />
            <motion.div
              className="absolute w-2 h-2 rounded-full bg-yellow-300"
              initial={{ x: 0, y: 0, opacity: 1 }}
              animate={{ x: 20, y: 20, opacity: 0 }}
              transition={{ duration: 1, delay: 0.4, repeat: Number.POSITIVE_INFINITY }}
            />
            <motion.div
              className="absolute w-2 h-2 rounded-full bg-yellow-300"
              initial={{ x: 0, y: 0, opacity: 1 }}
              animate={{ x: -20, y: 20, opacity: 0 }}
              transition={{ duration: 1, delay: 0.6, repeat: Number.POSITIVE_INFINITY }}
            />
          </>
        )}

        {/* Иконка */}
        <motion.div
          className="relative z-10"
          animate={{
            rotate: isHovered ? [0, 15, -15, 0] : 0,
            scale: isHovered ? [1, 1.2, 1] : 1,
          }}
          transition={{ duration: 0.5 }}
        >
          <div className="w-10 h-10 flex items-center justify-center">
            <Image
              src="/images/slots/cherry.png"
              alt="Casino"
              width={40}
              height={40}
              className="w-full h-full object-contain"
            />
          </div>
        </motion.div>
      </motion.button>

      {/* Подсказка */}
      <motion.div
        className="absolute right-full mr-3 top-1/2 transform -translate-y-1/2 bg-indigo-600 text-white px-3 py-2 rounded-lg whitespace-nowrap font-medium text-sm shadow-lg"
        initial={{ opacity: 0, x: 10 }}
        animate={{ opacity: isHovered ? 1 : 0, x: isHovered ? 0 : 10 }}
        transition={{ duration: 0.2 }}
      >
        Испытай удачу!
        <motion.div className="absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2 rotate-45 w-2 h-2 bg-indigo-600" />
      </motion.div>
    </motion.div>
  )
}
