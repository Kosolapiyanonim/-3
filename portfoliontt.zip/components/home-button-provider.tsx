"use client"

import { usePathname } from "next/navigation"
import { SimpleHomeButton } from "@/components/simple-home-button"
import { useEffect, useState } from "react"

export function HomeButtonProvider() {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  // Не показываем кнопку на главной странице
  if (pathname === "/") return null

  return <SimpleHomeButton />
}
