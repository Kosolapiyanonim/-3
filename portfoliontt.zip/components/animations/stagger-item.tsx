"use client"

import type { ReactNode } from "react"
import { motion } from "framer-motion"

interface StaggerItemProps {
  children: ReactNode
  className?: string
  direction?: "up" | "down" | "left" | "right"
  duration?: number
}

export function StaggerItem({ children, className, direction = "up", duration = 0.5 }: StaggerItemProps) {
  const getDirectionOffset = () => {
    switch (direction) {
      case "up":
        return { y: 40 }
      case "down":
        return { y: -40 }
      case "left":
        return { x: 40 }
      case "right":
        return { x: -40 }
      default:
        return { y: 40 }
    }
  }

  return (
    <motion.div
      className={className}
      variants={{
        hidden: { opacity: 0, ...getDirectionOffset() },
        visible: {
          opacity: 1,
          x: 0,
          y: 0,
          transition: {
            duration,
            ease: "easeOut",
          },
        },
      }}
    >
      {children}
    </motion.div>
  )
}
