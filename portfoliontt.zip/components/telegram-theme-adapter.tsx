"use client"

import { useEffect } from "react"
import { useTheme } from "next-themes"
import { useTelegramWebApp } from "@/hooks/use-telegram-webapp"

export function TelegramThemeAdapter() {
  const { setTheme } = useTheme()
  const { isTelegramWebApp, telegramTheme } = useTelegramWebApp()

  useEffect(() => {
    if (isTelegramWebApp && telegramTheme) {
      // Устанавливаем тему в соответствии с темой Telegram
      setTheme(telegramTheme === "dark" ? "dark" : "light")
    }
  }, [isTelegramWebApp, telegramTheme, setTheme])

  return null
}
