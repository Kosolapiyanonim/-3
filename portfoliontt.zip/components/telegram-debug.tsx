"use client"

import { useEffect } from "react"

export function TelegramDebug() {
  useEffect(() => {
    // Функция для проверки Telegram WebApp
    const checkTelegramWebApp = () => {
      if (typeof window !== "undefined") {
        console.log("Проверка Telegram WebApp:")
        console.log("window.Telegram существует:", !!window.Telegram)

        if (window.Telegram) {
          console.log("window.Telegram.WebApp существует:", !!window.Telegram.WebApp)

          if (window.Telegram.WebApp) {
            console.log("isExpanded:", window.Telegram.WebApp.isExpanded)
            console.log("colorScheme:", window.Telegram.WebApp.colorScheme)

            // Пробуем развернуть
            try {
              window.Telegram.WebApp.expand()
              console.log("Метод expand() вызван")
              console.log("isExpanded после вызова:", window.Telegram.WebApp.isExpanded)
            } catch (error) {
              console.error("Ошибка при вызове expand():", error)
            }
          }
        }
      }
    }

    // Проверяем сразу
    checkTelegramWebApp()

    // Проверяем через 1 секунду
    const timeout = setTimeout(checkTelegramWebApp, 1000)

    return () => clearTimeout(timeout)
  }, [])

  return null
}
