import type React from "react"

interface BrandTelegramProps extends React.SVGProps<SVGSVGElement> {}

export function BrandTelegram(props: BrandTelegramProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M22 3 L2 10 L11 14 L17 8 L10 15 L10 19 L14 21 L18 11 L22 3 Z" />
    </svg>
  )
}
