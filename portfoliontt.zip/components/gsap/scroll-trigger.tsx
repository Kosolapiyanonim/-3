"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

// Register the plugin
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger)
}

interface ScrollTriggerProps {
  children: React.ReactNode
  animation?: "fade" | "slide" | "scale" | "rotate" | "custom"
  start?: string // ScrollTrigger start position (e.g., "top bottom", "center center")
  end?: string // ScrollTrigger end position
  scrub?: boolean | number // Whether the animation should be tied to scroll position
  markers?: boolean // Show markers for debugging (only in development)
  delay?: number
  duration?: number
  className?: string
  customAnimation?: (element: HTMLElement) => gsap.core.Tween
}

export function GsapScrollTrigger({
  children,
  animation = "fade",
  start = "top bottom",
  end = "bottom top",
  scrub = false,
  markers = false,
  delay = 0,
  duration = 1,
  className,
  customAnimation,
}: ScrollTriggerProps) {
  const elementRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    const element = elementRef.current
    if (!element) return

    let tween: gsap.core.Tween

    // Create the animation based on the type
    if (customAnimation) {
      tween = customAnimation(element)
    } else {
      switch (animation) {
        case "fade":
          tween = gsap.fromTo(element, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration, delay, ease: "power2.out" })
          break
        case "slide":
          tween = gsap.fromTo(
            element,
            { x: -50, opacity: 0 },
            { x: 0, opacity: 1, duration, delay, ease: "power2.out" },
          )
          break
        case "scale":
          tween = gsap.fromTo(
            element,
            { scale: 0.8, opacity: 0 },
            { scale: 1, opacity: 1, duration, delay, ease: "back.out(1.7)" },
          )
          break
        case "rotate":
          tween = gsap.fromTo(
            element,
            { rotation: -5, opacity: 0 },
            { rotation: 0, opacity: 1, duration, delay, ease: "power1.out" },
          )
          break
        default:
          tween = gsap.fromTo(element, { opacity: 0 }, { opacity: 1, duration, delay, ease: "power2.out" })
      }
    }

    // Create the ScrollTrigger
    const trigger = ScrollTrigger.create({
      trigger: element,
      start,
      end,
      scrub: scrub,
      markers: process.env.NODE_ENV === "development" && markers,
      animation: tween,
    })

    // Cleanup
    return () => {
      trigger.kill()
      tween.kill()
    }
  }, [animation, start, end, scrub, markers, delay, duration, customAnimation])

  return (
    <div ref={elementRef} className={className}>
      {children}
    </div>
  )
}
