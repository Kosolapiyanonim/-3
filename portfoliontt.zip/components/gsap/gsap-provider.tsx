"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import { ScrollSmoother } from "gsap/ScrollSmoother"
import { Observer } from "gsap/Observer"
import { usePathname } from "next/navigation"

// Регистрируем плагины
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger, ScrollSmoother, Observer)
}

interface GsapProviderProps {
  children: React.ReactNode
}

export function GsapProvider({ children }: GsapProviderProps) {
  const smootherRef = useRef<any>(null)
  const wrapperRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const [isReady, setIsReady] = useState(false)
  const pathname = usePathname()

  // Инициализация ScrollSmoother
  useEffect(() => {
    if (typeof window === "undefined") return

    // Создаем ScrollSmoother только один раз
    if (!smootherRef.current && wrapperRef.current && contentRef.current) {
      // Небольшая задержка для уверенности, что DOM полностью загружен
      const timer = setTimeout(() => {
        smootherRef.current = ScrollSmoother.create({
          wrapper: wrapperRef.current,
          content: contentRef.current,
          smooth: 1.5, // Скорость прокрутки (1 = нормальная)
          effects: true, // Включаем эффекты для data-speed атрибутов
          normalizeScroll: true, // Нормализация прокрутки для разных устройств
          ignoreMobileResize: true, // Игнорировать изменение размера на мобильных устройствах
        })
        setIsReady(true)
      }, 100)

      return () => clearTimeout(timer)
    }

    return () => {
      // Очистка при размонтировании
      if (smootherRef.current) {
        smootherRef.current.kill()
      }
    }
  }, [])

  // Обновляем ScrollTrigger при изменении пути
  useEffect(() => {
    if (isReady && smootherRef.current) {
      // Сбрасываем прокрутку при переходе на новую страницу
      smootherRef.current.scrollTop(0)

      // Обновляем ScrollTrigger
      ScrollTrigger.refresh()
    }
  }, [pathname, isReady])

  return (
    <div ref={wrapperRef} className="smooth-wrapper">
      <div ref={contentRef} className="smooth-content">
        {children}
      </div>
    </div>
  )
}
