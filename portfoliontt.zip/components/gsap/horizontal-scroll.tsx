"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

// Register the plugin
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger)
}

interface HorizontalScrollProps {
  children: React.ReactNode
  className?: string
  containerClassName?: string
  speed?: number // Speed multiplier
}

export function GsapHorizontalScroll({
  children,
  className = "",
  containerClassName = "",
  speed = 1,
}: HorizontalScrollProps) {
  const sectionRef = useRef<HTMLDivElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    const section = sectionRef.current
    const container = containerRef.current

    if (!section || !container) return

    // Calculate the width the container should scroll
    const calculateWidth = () => {
      const containerWidth = container.scrollWidth
      const viewportWidth = window.innerWidth
      return -(containerWidth - viewportWidth)
    }

    // Create the horizontal scroll effect
    const tween = gsap.to(container, {
      x: calculateWidth,
      ease: "none",
      scrollTrigger: {
        trigger: section,
        start: "top top",
        end: () => `+=${container.scrollWidth - window.innerWidth}`,
        pin: true,
        anticipatePin: 1,
        scrub: speed,
        invalidateOnRefresh: true,
      },
    })

    // Update on resize
    const handleResize = () => {
      ScrollTrigger.refresh()
    }

    window.addEventListener("resize", handleResize)

    // Cleanup
    return () => {
      tween.kill()
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill())
      window.removeEventListener("resize", handleResize)
    }
  }, [speed])

  return (
    <div ref={sectionRef} className={`horizontal-section ${className}`}>
      <div ref={containerRef} className={`horizontal-container ${containerClassName}`}>
        {children}
      </div>
    </div>
  )
}
