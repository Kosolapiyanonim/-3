"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
import SplitType from "split-type"

// Register the plugin
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger)
}

interface TextRevealProps {
  children: React.ReactNode
  stagger?: number // Time between each character animation
  duration?: number
  delay?: number
  className?: string
}

export function GsapTextReveal({ children, stagger = 0.05, duration = 0.5, delay = 0, className }: TextRevealProps) {
  const textRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    const element = textRef.current
    if (!element) return

    // Split the text into characters
    const splitText = new SplitType(element, { types: "chars, words" })
    const chars = splitText.chars

    if (!chars) return

    // Create the animation
    const tween = gsap.fromTo(
      chars,
      {
        y: 20,
        opacity: 0,
      },
      {
        y: 0,
        opacity: 1,
        stagger,
        duration,
        delay,
        ease: "power4.out",
        scrollTrigger: {
          trigger: element,
          start: "top bottom-=100",
          toggleActions: "play none none none",
        },
      },
    )

    // Cleanup
    return () => {
      tween.kill()
      if (splitText) splitText.revert()
    }
  }, [stagger, duration, delay])

  return (
    <div ref={textRef} className={className}>
      {children}
    </div>
  )
}
