"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

// Register the plugin
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger)
}

interface ParallaxProps {
  children: React.ReactNode
  speed?: number // Parallax speed (negative values move in opposite direction)
  className?: string
}

export function GsapParallax({ children, speed = 0.5, className }: ParallaxProps) {
  const elementRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    const element = elementRef.current
    if (!element) return

    // Create the parallax effect
    const tween = gsap.fromTo(
      element,
      { y: 0 },
      {
        y: () => speed * 100, // The distance to move (based on speed)
        ease: "none",
        scrollTrigger: {
          trigger: element,
          start: "top bottom",
          end: "bottom top",
          scrub: true,
        },
      },
    )

    // Cleanup
    return () => {
      tween.kill()
      ScrollTrigger.getAll().forEach((trigger) => trigger.kill())
    }
  }, [speed])

  return (
    <div ref={elementRef} className={className}>
      {children}
    </div>
  )
}
