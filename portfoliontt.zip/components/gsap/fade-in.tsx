"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import gsap from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"

// Register the plugin
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger)
}

interface FadeInProps {
  children: React.ReactNode
  direction?: "up" | "down" | "left" | "right" | "none"
  duration?: number
  delay?: number
  stagger?: number
  threshold?: number
  className?: string
}

export function GsapFadeIn({
  children,
  direction = "up",
  duration = 0.8,
  delay = 0,
  stagger = 0,
  threshold = 0.1,
  className = "",
}: FadeInProps) {
  const elementRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    const element = elementRef.current
    if (!element) return

    // Set initial state based on direction
    const getInitialState = () => {
      const baseState = { opacity: 0 }
      const distance = 50

      switch (direction) {
        case "up":
          return { ...baseState, y: distance }
        case "down":
          return { ...baseState, y: -distance }
        case "left":
          return { ...baseState, x: distance }
        case "right":
          return { ...baseState, x: -distance }
        case "none":
          return baseState
        default:
          return { ...baseState, y: distance }
      }
    }

    // Set target state
    const targetState = {
      opacity: 1,
      x: 0,
      y: 0,
      duration,
      delay,
      stagger,
      ease: "power3.out",
    }

    // Create the animation
    const elements = stagger > 0 ? element.children : element

    const tween = gsap.fromTo(elements, getInitialState(), {
      ...targetState,
      scrollTrigger: {
        trigger: element,
        start: `top bottom-=${threshold * 100}%`,
        toggleActions: "play none none none",
      },
    })

    // Cleanup
    return () => {
      tween.kill()
    }
  }, [direction, duration, delay, stagger, threshold])

  return (
    <div ref={elementRef} className={className}>
      {children}
    </div>
  )
}
