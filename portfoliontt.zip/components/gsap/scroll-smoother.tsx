"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import gsap from "gsap"
import { ScrollSmoother } from "gsap/ScrollSmoother"
import { ScrollTrigger } from "gsap/ScrollTrigger"

// Register the plugins
if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollSmoother, ScrollTrigger)
}

interface ScrollSmootherProps {
  children: React.ReactNode
  speed?: number
  smooth?: number
  effects?: boolean
  className?: string
  contentClassName?: string
}

export function GsapScrollSmoother({
  children,
  speed = 1,
  smooth = 1,
  effects = true,
  className = "",
  contentClassName = "",
}: ScrollSmootherProps) {
  const wrapperRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const smootherRef = useRef<any>(null)

  useEffect(() => {
    // Only run on client side
    if (typeof window === "undefined") return

    const wrapper = wrapperRef.current
    const content = contentRef.current

    if (!wrapper || !content) return

    // Create ScrollSmoother
    smootherRef.current = ScrollSmoother.create({
      wrapper: wrapper,
      content: content,
      smooth: smooth,
      effects: effects,
      normalizeScroll: true,
      ignoreMobileResize: true,
    })

    // Cleanup
    return () => {
      if (smootherRef.current) {
        smootherRef.current.kill()
      }
    }
  }, [smooth, effects])

  return (
    <div ref={wrapperRef} className={`smooth-wrapper ${className}`}>
      <div ref={contentRef} className={`smooth-content ${contentClassName}`}>
        {children}
      </div>
    </div>
  )
}
