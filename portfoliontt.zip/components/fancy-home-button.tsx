"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion, useAnimation } from "framer-motion"
import { Home, ArrowLeft } from "lucide-react"

export function FancyHomeButton() {
  const router = useRouter()
  const controls = useAnimation()
  const [isHovered, setIsHovered] = useState(false)
  const [isClicked, setIsClicked] = useState(false)

  // Эффект появления кнопки
  useEffect(() => {
    // Используем безопасный способ анимации для React 18
    const animateButton = async () => {
      await controls.start({
        opacity: 1,
        scale: 1,
        transition: { duration: 0.5, delay: 0.3 },
      })
    }

    animateButton()
  }, [controls])

  const handleClick = () => {
    setIsClicked(true)

    // Анимация перед переходом
    controls
      .start({
        scale: [1, 1.2, 0.8, 0],
        opacity: [1, 1, 1, 0],
        transition: { duration: 0.8, ease: "easeInOut" },
      })
      .then(() => {
        router.push("/")
      })
  }

  return (
    <motion.div className="fixed bottom-6 right-6 z-[9999]" initial={{ opacity: 0, scale: 0 }} animate={controls}>
      <motion.button
        className={`flex items-center justify-center rounded-full h-14 w-14 shadow-lg bg-primary text-primary-foreground transition-all duration-300 ${
          isHovered ? "shadow-xl" : ""
        }`}
        whileHover={{
          scale: 1.1,
          boxShadow: "0 10px 25px rgba(0, 0, 0, 0.2)",
        }}
        whileTap={{ scale: 0.95 }}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        onClick={handleClick}
        disabled={isClicked}
      >
        <motion.div animate={isHovered ? { rotate: 360 } : {}} transition={{ duration: 0.5 }}>
          {isHovered ? <ArrowLeft className="h-6 w-6" /> : <Home className="h-6 w-6" />}
        </motion.div>
      </motion.button>

      {isHovered && (
        <motion.div
          className="absolute right-16 top-1/2 -translate-y-1/2 bg-primary text-primary-foreground px-3 py-1 rounded-md whitespace-nowrap"
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
        >
          На главную
        </motion.div>
      )}
    </motion.div>
  )
}
