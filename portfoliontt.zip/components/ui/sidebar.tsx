"use client"

import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

// Определение типов и контекста
interface SidebarContextValue {
  open: boolean
  setOpen: React.Dispatch<React.SetStateAction<boolean>>
}

const SidebarContext = React.createContext<SidebarContextValue | undefined>(undefined)

// Провайдер для сайдбара
export function SidebarProvider2({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = React.useState(true)
  return <SidebarContext.Provider value={{ open, setOpen }}>{children}</SidebarContext.Provider>
}

// Хук для использования контекста сайдбара
export function useSidebar2() {
  const context = React.useContext(SidebarContext)
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider")
  }
  return context
}

// Варианты стилей для сайдбара
const sidebarVariants = cva(
  "h-screen flex flex-col bg-sidebar border-r border-sidebar-border transition-all duration-300 ease-in-out md:w-[250px]",
  {
    variants: {
      open: {
        true: "translate-x-0 w-[220px]",
        false: "-translate-x-full md:translate-x-0 md:w-[70px]",
      },
    },
    defaultVariants: {
      open: true,
    },
  },
)

// Компонент сайдбара
interface SidebarProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof sidebarVariants> {
  onOpenChange?: (open: boolean) => void
}

export function Sidebar({ className, open, onOpenChange, ...props }: SidebarProps) {
  const context = useSidebar2()
  const isOpen = open !== undefined ? open : context.open

  React.useEffect(() => {
    if (onOpenChange) {
      onOpenChange(isOpen)
    }
  }, [isOpen, onOpenChange])

  return (
    <>
      {/* Overlay для мобильных устройств */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden"
          onClick={() => {
            context.setOpen(false)
            if (onOpenChange) onOpenChange(false)
          }}
        />
      )}
      <div
        className={cn(
          sidebarVariants({ open: isOpen }),
          "md:sticky md:top-0 md:left-0 md:h-screen",
          "fixed inset-y-0 left-0 z-50 md:z-10",
          className,
        )}
        {...props}
      />
    </>
  )
}

// Компоненты для сайдбара
export function SidebarHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex h-14 items-center border-b border-sidebar-border px-4", className)} {...props} />
}

export function SidebarContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex-1 overflow-y-auto overflow-x-hidden h-full", className)} {...props} />
}

export function SidebarFooter({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("border-t border-sidebar-border", className)} {...props} />
}

export function SidebarMenu({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("flex flex-col gap-1 p-2", className)} {...props} />
}

export function SidebarMenuItem({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("", className)} {...props} />
}

interface SidebarMenuButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isActive?: boolean
  tooltip?: string
  asChild?: boolean
}

export function SidebarMenuButton({ className, isActive, tooltip, asChild = false, ...props }: SidebarMenuButtonProps) {
  const Comp = asChild ? React.Fragment : "button"
  const childProps = asChild ? {} : props

  return (
    <Comp {...childProps}>
      <div
        className={cn(
          "group flex w-full cursor-pointer items-center gap-2 rounded-md px-3 py-2 text-sidebar-foreground transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
          isActive && "bg-sidebar-accent font-medium text-sidebar-accent-foreground",
          className,
        )}
        title={tooltip}
        {...(asChild ? props : {})}
      />
    </Comp>
  )
}

export function SidebarTrigger({ className, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const { open, setOpen } = useSidebar2()

  return (
    <button
      className={cn(
        "inline-flex h-8 w-8 items-center justify-center rounded-md text-sidebar-foreground transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
        className,
      )}
      onClick={() => setOpen(!open)}
      {...props}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-4 w-4"
      >
        <path d="M18 6 6 18" />
        <path d="m6 6 12 12" />
      </svg>
      <span className="sr-only">Close sidebar</span>
    </button>
  )
}

// Экспорт дополнительных компонентов
export function SidebarSeparator({ className, ...props }: React.ComponentProps<typeof Separator>) {
  return <Separator className={cn("mx-2 w-auto bg-sidebar-border", className)} {...props} />
}

export function SidebarRail() {
  return null
}

export function SidebarInset({ className, ...props }: React.ComponentProps<"main">) {
  return <main className={cn("relative flex min-h-svh flex-1 flex-col bg-background", className)} {...props} />
}

export function SidebarInput({ className, ...props }: React.ComponentProps<typeof Input>) {
  return (
    <Input
      className={cn(
        "h-8 w-full bg-background shadow-none focus-visible:ring-2 focus-visible:ring-sidebar-ring",
        className,
      )}
      {...props}
    />
  )
}

export function SidebarGroup({ className, ...props }: React.ComponentProps<"div">) {
  return <div className={cn("relative flex w-full min-w-0 flex-col p-2", className)} {...props} />
}

export function SidebarGroupLabel({
  className,
  asChild = false,
  ...props
}: React.ComponentProps<"div"> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "div"
  return (
    <Comp
      className={cn(
        "flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70",
        className,
      )}
      {...props}
    />
  )
}

export function SidebarGroupAction({ className, ...props }: React.ComponentProps<"button">) {
  return (
    <button
      className={cn(
        "absolute right-3 top-3.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground",
        className,
      )}
      {...props}
    />
  )
}

export function SidebarGroupContent({ className, ...props }: React.ComponentProps<"div">) {
  return <div className={cn("w-full text-sm", className)} {...props} />
}

export function SidebarMenuAction({ className, ...props }: React.ComponentProps<"button">) {
  return (
    <button
      className={cn(
        "absolute right-1 top-1.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground",
        className,
      )}
      {...props}
    />
  )
}

export function SidebarMenuBadge({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      className={cn(
        "absolute right-1 flex h-5 min-w-5 items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums text-sidebar-foreground",
        className,
      )}
      {...props}
    />
  )
}

export function SidebarMenuSkeleton({ className, ...props }: React.ComponentProps<"div">) {
  return <div className={cn("rounded-md h-8 flex gap-2 px-2 items-center", className)} {...props} />
}

export function SidebarMenuSub({ className, ...props }: React.ComponentProps<"ul">) {
  return (
    <ul
      className={cn(
        "mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5",
        className,
      )}
      {...props}
    />
  )
}

export function SidebarMenuSubItem(props: React.ComponentProps<"li">) {
  return <li {...props} />
}

export function SidebarMenuSubButton({ className, ...props }: React.ComponentProps<"a">) {
  return (
    <a
      className={cn(
        "flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground",
        className,
      )}
      {...props}
    />
  )
}
