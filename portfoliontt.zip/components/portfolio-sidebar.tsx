"use client"

import { useState, useCallback, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { ModeToggle } from "@/components/mode-toggle"
import { Button } from "@/components/ui/button"
import {
  Home,
  User,
  Briefcase,
  Mail,
  Github,
  Linkedin,
  Twitter,
  Menu,
  X,
  FolderKanban,
  DollarSign,
  Users,
  ShieldCheck,
} from "lucide-react"
import { useIsMobile } from "@/hooks/use-mobile"

export function PortfolioSidebar() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const isMobile = useIsMobile()

  // Автоматически закрывать сайдбар после клика на мобильных устройствах
  const handleLinkClick = useCallback(() => {
    if (isMobile) {
      setOpen(false)
    }
  }, [isMobile])

  // Закрывать сайдбар по умолчанию на мобильных устройствах
  useEffect(() => {
    setOpen(!isMobile)
  }, [isMobile])

  const routes = [
    {
      title: "Главная",
      icon: Home,
      href: "/",
    },
    {
      title: "Обо мне",
      icon: User,
      href: "/about",
    },
    {
      title: "Кейсы",
      icon: FolderKanban,
      href: "/cases",
    },
    {
      title: "Портфолио",
      icon: Briefcase,
      href: "/portfolio",
    },
    {
      title: "Заработай со мной",
      icon: DollarSign,
      href: "/earn-with-me",
    },
    {
      title: "Исполнителям",
      icon: Users,
      href: "/for-performers",
    },
    {
      title: "Админам",
      icon: ShieldCheck,
      href: "/for-admins",
    },
    {
      title: "Связаться",
      icon: Mail,
      href: "/contact",
    },
  ]

  return (
    <>
      <div className="sticky top-0 z-40 flex items-center justify-between border-b bg-background p-4 md:hidden">
        <Link href="/" className="flex items-center gap-2 font-bold">
          Портфолио NTT
        </Link>
        <div className="flex items-center gap-2">
          <ModeToggle />
          <Button variant="ghost" size="icon" onClick={() => setOpen(!open)} className="md:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Mobile overlay */}
      {open && isMobile && (
        <div
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-50 flex h-full w-64 flex-col border-r bg-background transition-transform duration-300 md:sticky md:top-0 md:z-0 ${
          open ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        }`}
      >
        <div className="flex h-14 items-center justify-between border-b px-4">
          <Link href="/" className="flex items-center gap-2 font-bold">
            Портфолио NTT
          </Link>
          <Button variant="ghost" size="icon" onClick={() => setOpen(false)} className="md:hidden">
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="flex-1 overflow-auto p-4">
          <nav className="flex flex-col gap-1">
            {routes.map((route) => (
              <Link
                key={route.href}
                href={route.href}
                onClick={handleLinkClick}
                className={`flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground ${
                  pathname === route.href ? "bg-accent text-accent-foreground" : "text-foreground"
                }`}
              >
                <route.icon className="h-5 w-5" />
                <span>{route.title}</span>
              </Link>
            ))}
          </nav>
        </div>

        <div className="border-t p-4">
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" asChild>
                <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                  <Github className="h-5 w-5" />
                  <span className="sr-only">GitHub</span>
                </a>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
                  <Linkedin className="h-5 w-5" />
                  <span className="sr-only">LinkedIn</span>
                </a>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                  <Twitter className="h-5 w-5" />
                  <span className="sr-only">Twitter</span>
                </a>
              </Button>
            </div>
            <ModeToggle />
          </div>
        </div>
      </div>
    </>
  )
}
