"use client"

import { useEffect } from "react"

declare global {
  interface Window {
    Telegram: {
      WebApp: {
        ready: () => void
        expand: () => void
        isExpanded: boolean
      }
    }
  }
}

export function TelegramWebApp() {
  useEffect(() => {
    // Проверяем, что мы находимся в Telegram WebApp
    if (window.Telegram && window.Telegram.WebApp) {
      // Сообщаем Telegram, что приложение готово
      window.Telegram.WebApp.ready()

      // Разворачиваем окно на весь экран
      if (!window.Telegram.WebApp.isExpanded) {
        window.Telegram.WebApp.expand()
      }
    }
  }, [])

  return null
}
