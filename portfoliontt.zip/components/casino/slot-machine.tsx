"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Volume2, VolumeX, Home, Gift, Sparkles, Zap, Coins } from "lucide-react"
import gsap from "gsap"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"
import confetti from "canvas-confetti"
import { Howl } from "howler"

// Символы для слот-машины с весами и множителями
const SYMBOLS = [
  {
    id: "diamond",
    value: 500,
    weight: 1,
    image: "/images/slots/diamond.png",
    name: "Бриллиант",
    color: "#4f46e5",
  },
  {
    id: "seven",
    value: 200,
    weight: 3,
    image: "/images/slots/seven.png",
    name: "Семерка",
    color: "#8b5cf6",
  },
  {
    id: "wild",
    value: 100,
    weight: 5,
    image: "/images/slots/wild.png",
    name: "Джокер",
    color: "#ec4899",
  },
  {
    id: "watermelon",
    value: 75,
    weight: 8,
    image: "/images/slots/watermelon.png",
    name: "Арбуз",
    color: "#f59e0b",
  },
  {
    id: "banana",
    value: 50,
    weight: 10,
    image: "/images/slots/banana.png",
    name: "Банан",
    color: "#10b981",
  },
  {
    id: "orange",
    value: 40,
    weight: 15,
    image: "/images/slots/orange.png",
    name: "Апельсин",
    color: "#3b82f6",
  },
  {
    id: "plum",
    value: 30,
    weight: 20,
    image: "/images/slots/plum.png",
    name: "Слива",
    color: "#ef4444",
  },
  {
    id: "lemon",
    value: 25,
    weight: 25,
    image: "/images/slots/lemon.png",
    name: "Лимон",
    color: "#f97316",
  },
  {
    id: "cherry",
    value: 20,
    weight: 30,
    image: "/images/slots/cherry.png",
    name: "Вишня",
    color: "#eab308",
  },
]

// Призы
const PRIZES = [
  {
    id: "test_day",
    name: "Бесплатный тестовый день контента",
    description: "Получите доступ к премиум контенту на один день совершенно бесплатно!",
    minValue: 50,
    maxValue: 99,
    price: 50,
    icon: "content",
    image: "/images/slots/cherry.png",
  },
  {
    id: "test_three_days",
    name: "Бесплатные 3 дня теста контента",
    description: "Целых три дня доступа к премиум контенту без оплаты!",
    minValue: 100,
    maxValue: 199,
    price: 100,
    icon: "content",
    image: "/images/slots/lemon.png",
  },
  {
    id: "test_week",
    name: "Бесплатная неделя контента",
    description: "Полная неделя доступа к премиум контенту - отличная возможность оценить все преимущества!",
    minValue: 200,
    maxValue: 299,
    price: 200,
    icon: "content",
    image: "/images/slots/plum.png",
  },
  {
    id: "consultation",
    name: "Консультация в телеграм стоимостью 15000",
    description: "Персональная консультация по вашему проекту или бизнесу через Telegram!",
    minValue: 300,
    maxValue: 399,
    price: 300,
    icon: "consultation",
    image: "/images/slots/orange.png",
  },
  {
    id: "call",
    name: "Созвон с ответом на вопрос",
    description: "Личный звонок для обсуждения вашего вопроса и получения экспертного ответа!",
    minValue: 400,
    maxValue: 499,
    price: 400,
    icon: "telegram",
    image: "/images/slots/banana.png",
  },
  {
    id: "admin_strategy",
    name: "Стратегия для админов ТГ каналов",
    description: "Готовая стратегия развития и монетизации для администраторов Telegram каналов!",
    minValue: 500,
    maxValue: 599,
    price: 500,
    icon: "admin",
    image: "/images/slots/watermelon.png",
  },
  {
    id: "channel_strategy",
    name: "Индивидуальная стратегия для ТГ канала на месяц",
    description: "Персонализированный план развития вашего Telegram канала на целый месяц!",
    minValue: 600,
    maxValue: 799,
    price: 600,
    icon: "strategy",
    image: "/images/slots/wild.png",
  },
  {
    id: "jackpot",
    name: "ДЖЕКПОТ: Менторка",
    description:
      "Полноценная программа менторства для вашего проекта или бизнеса! Максимальная поддержка и результаты!",
    minValue: 800,
    maxValue: 10000,
    price: 800,
    icon: "mentor",
    image: "/images/slots/diamond.png",
  },
]

// Линии выигрыша с визуальными координатами для отрисовки
const LINES = [
  {
    pattern: [1, 1, 1, 1, 1],
    name: "Средняя горизонтальная",
    color: "#ff5555",
    path: "M0,50 L100,50",
    gradient: "linear-gradient(90deg, rgba(255,85,85,0) 0%, rgba(255,85,85,1) 50%, rgba(255,85,85,0) 100%)",
    thickness: 4,
  },
  {
    pattern: [0, 0, 0, 0, 0],
    name: "Верхняя горизонтальная",
    color: "#55ff55",
    path: "M0,16.7 L100,16.7",
    gradient: "linear-gradient(90deg, rgba(85,255,85,0) 0%, rgba(85,255,85,1) 50%, rgba(85,255,85,0) 100%)",
    thickness: 4,
  },
  {
    pattern: [2, 2, 2, 2, 2],
    name: "Нижняя горизонтальная",
    color: "#5555ff",
    path: "M0,83.3 L100,83.3",
    gradient: "linear-gradient(90deg, rgba(85,85,255,0) 0%, rgba(85,85,255,1) 50%, rgba(85,85,255,0) 100%)",
    thickness: 4,
  },
  {
    pattern: [0, 1, 2, 1, 0],
    name: "V-образная",
    color: "#ffff55",
    path: "M0,16.7 Q50,83.3 100,16.7",
    gradient: "linear-gradient(90deg, rgba(255,255,85,0) 0%, rgba(255,255,85,1) 50%, rgba(255,255,85,0) 100%)",
    thickness: 4,
  },
  {
    pattern: [2, 1, 0, 1, 2],
    name: "Перевернутая V",
    color: "#ff55ff",
    path: "M0,83.3 Q50,16.7 100,83.3",
    gradient: "linear-gradient(90deg, rgba(255,85,255,0) 0%, rgba(255,85,255,1) 50%, rgba(255,85,255,0) 100%)",
    thickness: 4,
  },
  {
    pattern: [0, 0, 1, 2, 2],
    name: "Диагональ сверху вниз",
    color: "#55ffff",
    path: "M0,16.7 L100,83.3",
    gradient: "linear-gradient(90deg, rgba(85,255,255,0) 0%, rgba(85,255,255,1) 50%, rgba(85,255,255,0) 100%)",
    thickness: 4,
  },
  {
    pattern: [2, 2, 1, 0, 0],
    name: "Диагональ снизу вверх",
    color: "#ff9955",
    path: "M0,83.3 L100,16.7",
    gradient: "linear-gradient(90deg, rgba(255,153,85,0) 0%, rgba(255,153,85,1) 50%, rgba(255,153,85,0) 100%)",
    thickness: 4,
  },
  {
    pattern: [1, 0, 0, 0, 1],
    name: "Верхняя дуга",
    color: "#99ff55",
    path: "M0,50 Q50,0 100,50",
    gradient: "linear-gradient(90deg, rgba(153,255,85,0) 0%, rgba(153,255,85,1) 50%, rgba(153,255,85,0) 100%)",
    thickness: 4,
  },
  {
    pattern: [1, 2, 2, 2, 1],
    name: "Нижняя дуга",
    color: "#5599ff",
    path: "M0,50 Q50,100 100,50",
    gradient: "linear-gradient(90deg, rgba(85,153,255,0) 0%, rgba(85,153,255,1) 50%, rgba(85,153,255,0) 100%)",
    thickness: 4,
  },
  {
    pattern: [0, 1, 0, 1, 0],
    name: "Зигзаг верхний",
    color: "#ff5599",
    path: "M0,16.7 L25,50 L50,16.7 L75,50 L100,16.7",
    gradient: "linear-gradient(90deg, rgba(255,85,153,0) 0%, rgba(255,85,153,1) 50%, rgba(255,85,153,0) 100%)",
    thickness: 4,
  },
]

// Количество линий для выбора
const LINE_OPTIONS = [1, 5, 10]

// Варианты ставок
const BET_OPTIONS = [1, 3, 5, 10, 25, 50, 100]

// RTP (Return to Player) - процент возврата игроку
const RTP = 0.95 // 95% возврат

// Ссылка для получения приза
const PRIZE_LINK = "https://t.me/m/vOkludQ4YmEy"

// Звуки
const SOUNDS = {
  spin: new Howl({ src: ["/sounds/spin.mp3"], volume: 0.5 }),
  win: new Howl({ src: ["/sounds/win.mp3"], volume: 0.7 }),
  jackpot: new Howl({ src: ["/sounds/jackpot.mp3"], volume: 0.8 }),
  click: new Howl({ src: ["/sounds/click.mp3"], volume: 0.4 }),
}

export function SlotMachine() {
  const [reels, setReels] = useState(
    Array(5)
      .fill(null)
      .map(() => generateReel()),
  )
  const [spinning, setSpinning] = useState(false)
  const [balance, setBalance] = useState(1000) // Начальный баланс
  const [bet, setBet] = useState(5) // Ставка
  const [win, setWin] = useState(0)
  const [totalWin, setTotalWin] = useState(0)
  const [activeLines, setActiveLines] = useState(5)
  const [muted, setMuted] = useState(true)
  const [fastSpin, setFastSpin] = useState(false)
  const [visibleSymbols, setVisibleSymbols] = useState(
    Array(5)
      .fill(null)
      .map(() => [0, 0, 0]),
  )
  const [winningLines, setWinningLines] = useState<number[]>([])
  const [currentPrize, setCurrentPrize] = useState<(typeof PRIZES)[0] | null>(null)
  const [showPrize, setShowPrize] = useState(false)
  const [showPaytable, setShowPaytable] = useState(false)
  const [showLines, setShowLines] = useState(false)
  const [highlightedLine, setHighlightedLine] = useState<number | null>(null)
  const [lastWin, setLastWin] = useState(0)
  const [purchasedPrizes, setPurchasedPrizes] = useState<string[]>([])
  const reelsRef = useRef<HTMLDivElement>(null)
  const linesRef = useRef<SVGSVGElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const visibleSymbolsBeforeSpin = useRef<(typeof SYMBOLS)[][]>([])

  // Генерация случайного барабана с учетом весов символов
  function generateReel() {
    const reel = []
    const totalWeight = SYMBOLS.reduce((sum, symbol) => sum + symbol.weight, 0)

    for (let i = 0; i < 30; i++) {
      let random = Math.random() * totalWeight
      let selectedSymbol = SYMBOLS[0]

      for (const symbol of SYMBOLS) {
        random -= symbol.weight
        if (random <= 0) {
          selectedSymbol = symbol
          break
        }
      }

      reel.push(selectedSymbol)
    }

    return reel
  }

  // Обновление видимых символов
  function updateVisibleSymbols() {
    const newVisibleSymbols = reels.map((reel) => [0, 1, 2].map((i) => reel[i]))
    setVisibleSymbols(newVisibleSymbols)
  }

  // Воспроизведение звука
  const playSound = (sound: keyof typeof SOUNDS) => {
    if (!muted) {
      SOUNDS[sound].play()
    }
  }

  // Запуск вращения
  const spin = () => {
    if (spinning || balance < bet) return

    // Сохраняем текущие видимые символы перед вращением
    visibleSymbolsBeforeSpin.current = visibleSymbols.map((reel) => [...reel])

    // Списываем ставку с баланса
    setBalance((prev) => prev - bet)

    playSound("spin")
    setSpinning(true)
    setWin(0)
    setWinningLines([])
    setCurrentPrize(null)
    setShowPrize(false)
    setHighlightedLine(null)

    // Анимация вращения с помощью GSAP
    if (reelsRef.current) {
      const reelElements = reelsRef.current.querySelectorAll(".reel")
      const spinDuration = fastSpin ? 0.3 : 0.5
      const spinDelay = fastSpin ? 0.1 : 0.2

      // Генерируем новые барабаны с учетом RTP
      const newReels = reels.map((_, i) => {
        if (Math.random() < RTP) {
          // Повышенный шанс выигрыша
          return generateWinningReel(i)
        } else {
          // Обычный случайный барабан
          return generateReel()
        }
      })

      // Устанавливаем новые барабаны
      setReels(newReels)

      // Анимируем вращение для каждого барабана
      reelElements.forEach((reel, i) => {
        const delay = i * spinDelay // Задержка для каждого барабана

        gsap.to(reel, {
          y: "100%",
          duration: spinDuration + delay,
          ease: "power1.in",
          onComplete: () => {
            // Сбрасываем позицию
            gsap.set(reel, { y: "-100%" })
            gsap.to(reel, {
              y: "0%",
              duration: spinDuration,
              ease: "bounce.out",
              onComplete: () => {
                // Когда последний барабан остановился
                if (i === 4) {
                  setTimeout(
                    () => {
                      // Обновляем видимые символы и проверяем выигрыш
                      const newVisibleSymbols = newReels.map((reel) => [0, 1, 2].map((i) => reel[i]))
                      setVisibleSymbols(newVisibleSymbols)
                      checkWin(newVisibleSymbols)
                      setSpinning(false)
                    },
                    fastSpin ? 300 : 500,
                  )
                }
              },
            })
          },
        })
      })
    }
  }

  // Генерация барабана с повышенным шансом выигрыша
  const generateWinningReel = (reelIndex: number) => {
    const reel = generateReel()

    // Если это первый барабан, увеличиваем шанс появления ценных символов
    if (reelIndex === 0) {
      // Заменяем несколько символов на более ценные
      for (let i = 0; i < 3; i++) {
        const randomIndex = Math.floor(Math.random() * 5) + 1 // Позиции 1-5
        const randomSymbolIndex = Math.floor(Math.random() * 4) // Первые 4 символа (самые ценные)
        reel[randomIndex] = SYMBOLS[randomSymbolIndex]
      }
    }

    return reel
  }

  // Проверка выигрыша
  const checkWin = (symbols: (typeof SYMBOLS)[][]) => {
    let roundWin = 0
    const newWinningLines: number[] = []
    const lineDetails: { line: number; symbols: string[]; count: number; win: number }[] = []

    // Проверяем каждую активную линию
    for (let l = 0; l < activeLines; l++) {
      if (l >= LINES.length) break

      const line = LINES[l]
      const lineSymbols = line.pattern.map((row, col) => symbols[col][row])

      // Проверяем совпадения (минимум 3 одинаковых символа)
      const firstSymbol = lineSymbols[0]
      let count = 1

      for (let i = 1; i < lineSymbols.length; i++) {
        if (lineSymbols[i].id === firstSymbol.id) {
          count++
        } else {
          break
        }
      }

      if (count >= 3) {
        // Рассчитываем выигрыш на основе значения символа и количества совпадений
        const baseValue = firstSymbol.value
        const multiplier = count - 2 // 3 символа = x1, 4 символа = x2, 5 символов = x3
        const lineWin = (baseValue * multiplier * bet) / 5 // Учитываем ставку
        roundWin += lineWin
        newWinningLines.push(l)

        lineDetails.push({
          line: l,
          symbols: lineSymbols.slice(0, count).map((s) => s.name),
          count,
          win: lineWin,
        })
      }
    }

    if (roundWin > 0) {
      // Добавляем выигрыш к балансу
      setBalance((prev) => prev + roundWin)

      setWin(roundWin)
      setLastWin(roundWin)
      setTotalWin((prev) => prev + roundWin)
      setWinningLines(newWinningLines)

      // Определяем приз на основе значения выигрыша
      const prize = PRIZES.find((p) => roundWin >= p.minValue && roundWin <= p.maxValue) || PRIZES[0]
      setCurrentPrize(prize)

      // Воспроизводим звук выигрыша
      if (roundWin >= 300) {
        playSound("jackpot")
      } else {
        playSound("win")
      }

      // Если выигрыш большой, показываем окно с призом и запускаем конфетти
      if (roundWin >= 100) {
        setShowPrize(true)

        // Запускаем конфетти для больших выигрышей
        if (typeof window !== "undefined" && roundWin >= 300) {
          try {
            confetti({
              particleCount: roundWin > 500 ? 150 : 100,
              spread: 70,
              origin: { y: 0.6 },
              colors: ["#FFD700", "#FFA500", "#FF4500"],
            })
          } catch (e) {
            console.error("Confetti error:", e)
          }
        }
      }

      // Анимация выигрыша
      gsap.to(".win-value", {
        scale: 1.5,
        duration: 0.5,
        yoyo: true,
        repeat: 3,
        ease: "elastic.out",
      })

      // Анимируем линии выигрыша
      animateWinningLines(newWinningLines)
    }
  }

  // Анимация выигрышных линий
  const animateWinningLines = (lines: number[]) => {
    if (!linesRef.current) return

    const linePaths = linesRef.current.querySelectorAll("path")

    // Сначала скрываем все линии
    linePaths.forEach((path) => {
      gsap.set(path, { opacity: 0 })
    })

    // Затем анимируем выигрышные линии по очереди
    lines.forEach((lineIndex, i) => {
      const path = linePaths[lineIndex]
      if (!path) return

      gsap
        .timeline()
        .to(path, { opacity: 1, duration: 0.3, delay: i * 0.5 })
        .to(path, { opacity: 0, duration: 0.3, delay: 0.5 })
    })

    // После показа всех линий по отдельности, показываем все вместе
    if (lines.length > 0) {
      gsap
        .timeline({ delay: lines.length * 0.5 + 1 })
        .to(
          lines.map((i) => linePaths[i]),
          { opacity: 1, duration: 0.5 },
        )
        .to(
          lines.map((i) => linePaths[i]),
          { opacity: 0, duration: 0.5, delay: 1 },
        )
    }
  }

  // Изменение ставки
  const changeBet = (newBet: number) => {
    if (spinning) return
    playSound("click")
    setBet(newBet)
  }

  // Изменение количества линий
  const changeLines = (lines: number) => {
    if (spinning) return
    playSound("click")
    setActiveLines(lines)
  }

  // Добавление баланса (для демо)
  const addBalance = () => {
    playSound("click")
    setBalance((prev) => prev + 1000)
  }

  // Закрытие окна с призом
  const closePrize = () => {
    playSound("click")
    setShowPrize(false)
  }

  // Покупка приза
  const buyPrize = () => {
    if (!currentPrize || balance < currentPrize.price) return

    playSound("click")

    // Списываем стоимость приза с баланса
    setBalance((prev) => prev - currentPrize.price)

    // Добавляем приз в список купленных
    setPurchasedPrizes((prev) => [...prev, currentPrize.id])

    // Закрываем окно
    setShowPrize(false)
  }

  // Получение приза
  const claimPrize = () => {
    playSound("click")
    // Перенаправляем на страницу получения приза
    window.location.href = PRIZE_LINK
  }

  // Показать/скрыть таблицу выплат
  const togglePaytable = () => {
    playSound("click")
    setShowPaytable(!showPaytable)
    setShowLines(false)
  }

  // Показать/скрыть линии
  const toggleLines = () => {
    playSound("click")
    setShowLines(!showLines)
    setShowPaytable(false)
  }

  // Подсветка линии при наведении
  const highlightLine = (index: number) => {
    setHighlightedLine(index)
  }

  // Убрать подсветку линии
  const unhighlightLine = () => {
    setHighlightedLine(null)
  }

  // Переключение звука
  const toggleSound = () => {
    setMuted(!muted)
  }

  // Переключение скорости вращения
  const toggleFastSpin = () => {
    playSound("click")
    setFastSpin(!fastSpin)
  }

  // Эффект для инициализации видимых символов при первой загрузке
  useEffect(() => {
    updateVisibleSymbols()
  }, [])

  return (
    <div className="flex flex-col items-center w-full max-w-4xl mx-auto">
      <motion.div
        className="relative w-full bg-gradient-to-b from-indigo-900 to-purple-900 rounded-2xl border-4 border-yellow-400 shadow-[0_0_30px_rgba(79,70,229,0.5)] overflow-hidden"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Верхняя панель */}
        <div className="sticky top-0 left-0 right-0 h-14 bg-gradient-to-r from-yellow-500 via-yellow-400 to-yellow-500 flex items-center justify-between px-4 z-10">
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10 rounded-full bg-indigo-600 hover:bg-indigo-500 text-yellow-300 shadow-md transition-all duration-300 hover:scale-105"
            onClick={() => (window.location.href = "/")}
          >
            <Home className="h-5 w-5" />
          </Button>
          <div className="text-indigo-900 font-bold text-xl md:text-2xl tracking-wide">Колесо Фортуны</div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className={cn(
                "h-10 w-10 rounded-full bg-indigo-600 hover:bg-indigo-500 text-yellow-300 shadow-md transition-all duration-300 hover:scale-105",
                fastSpin && "bg-yellow-600 hover:bg-yellow-500",
              )}
              onClick={toggleFastSpin}
              title={fastSpin ? "Обычная скорость" : "Ускоренное вращение"}
            >
              <Zap className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-10 w-10 rounded-full bg-indigo-600 hover:bg-indigo-500 text-yellow-300 shadow-md transition-all duration-300 hover:scale-105"
              onClick={toggleSound}
            >
              {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Информационная панель */}
        <div className="bg-indigo-950/80 p-3 flex justify-between items-center text-yellow-300 text-sm backdrop-blur-sm">
          <motion.div className="flex items-center gap-1" whileHover={{ scale: 1.05 }}>
            <Sparkles className="h-4 w-4" />
            <span>RTP: 95%</span>
          </motion.div>
          <motion.div className="flex items-center gap-1" whileHover={{ scale: 1.05 }}>
            <span>
              Линии: {activeLines}/{LINES.length}
            </span>
          </motion.div>
          <motion.div className="flex items-center gap-1" whileHover={{ scale: 1.05 }}>
            <Coins className="h-4 w-4" />
            <span>Баланс: {balance}</span>
          </motion.div>
        </div>

        {/* Слот-машина */}
        <div className="relative">
          {/* Линии выигрыша (SVG) */}
          <svg
            ref={linesRef}
            className="absolute inset-0 w-full h-full z-10 pointer-events-none"
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
          >
            {LINES.map((line, index) => (
              <path
                key={index}
                d={line.path}
                stroke={line.color}
                strokeWidth={line.thickness}
                fill="none"
                strokeDasharray="none"
                opacity={winningLines.includes(index) || highlightedLine === index ? 1 : 0}
                className="transition-opacity duration-300"
                style={{
                  filter: "drop-shadow(0 0 3px rgba(255, 255, 255, 0.7))",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                }}
              />
            ))}
          </svg>

          <div
            ref={reelsRef}
            className="w-full aspect-[16/9] flex gap-1 bg-indigo-950 border-2 border-indigo-600 overflow-hidden p-1"
          >
            {reels.map((reel, reelIndex) => (
              <div key={reelIndex} className="reel flex-1 relative">
                <div className="absolute inset-0 flex flex-col">
                  {[0, 1, 2].map((position) => (
                    <div
                      key={position}
                      className={cn(
                        "flex-1 flex items-center justify-center p-1 transition-all duration-300",
                        winningLines.some((l) => LINES[l].pattern[reelIndex] === position) &&
                          "bg-yellow-500/30 rounded-lg",
                      )}
                    >
                      {visibleSymbols[reelIndex] && visibleSymbols[reelIndex][position] && (
                        <motion.div
                          className="w-full h-full flex items-center justify-center"
                          initial={{ scale: 0.8, opacity: 0.8 }}
                          animate={{
                            scale: winningLines.some((l) => LINES[l].pattern[reelIndex] === position) ? [1, 1.1, 1] : 1,
                            opacity: 1,
                          }}
                          transition={{
                            duration: 0.5,
                            repeat: winningLines.some((l) => LINES[l].pattern[reelIndex] === position) ? 3 : 0,
                            repeatType: "reverse",
                          }}
                        >
                          <div
                            className={cn(
                              "w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center rounded-full p-1",
                              winningLines.some((l) => LINES[l].pattern[reelIndex] === position) &&
                                "ring-2 ring-yellow-400 ring-opacity-70 shadow-[0_0_15px_rgba(255,215,0,0.7)]",
                            )}
                            style={{
                              background: `radial-gradient(circle, ${visibleSymbols[reelIndex][position]?.color || "#4f46e5"}22, ${visibleSymbols[reelIndex][position]?.color || "#4f46e5"}44)`,
                            }}
                          >
                            <div
                              className={cn(
                                "w-full h-full relative transform transition-transform duration-300",
                                winningLines.some((l) => LINES[l].pattern[reelIndex] === position) && "animate-pulse",
                              )}
                            >
                              <Image
                                src={visibleSymbols[reelIndex][position]?.image || "/images/slots/cherry.png"}
                                alt={visibleSymbols[reelIndex][position]?.name || "Symbol"}
                                width={64}
                                height={64}
                                className="w-full h-full object-contain drop-shadow-lg"
                                style={{
                                  filter: winningLines.some((l) => LINES[l].pattern[reelIndex] === position)
                                    ? "drop-shadow(0 0 8px rgba(255, 215, 0, 0.7))"
                                    : "drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3))",
                                }}
                              />
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Нижняя панель */}
        <div className="bg-gradient-to-r from-indigo-800 via-indigo-700 to-indigo-800 p-3 flex flex-wrap items-center justify-between gap-2">
          <motion.div className="flex items-center gap-2" whileHover={{ scale: 1.05 }}>
            <div className="bg-indigo-950 text-yellow-300 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium shadow-inner">
              БАЛАНС: <span className="font-bold">{balance}</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="h-9 bg-yellow-500 hover:bg-yellow-400 text-indigo-900 font-bold text-xs rounded-lg shadow-md transition-all duration-300 hover:scale-105"
              onClick={addBalance}
            >
              +1000
            </Button>
          </motion.div>

          <div className="bg-indigo-950 text-yellow-300 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium shadow-inner win-value">
            ВЫИГРЫШ:{" "}
            <AnimatePresence mode="wait">
              <motion.span
                key={win}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="font-bold"
              >
                {win}
              </motion.span>
            </AnimatePresence>
          </div>

          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              className="bg-gradient-to-b from-yellow-500 to-yellow-600 hover:from-yellow-400 hover:to-yellow-500 text-indigo-900 font-bold px-6 py-3 rounded-lg shadow-lg border-2 border-yellow-300 text-sm sm:text-base transition-all duration-300"
              onClick={spin}
              disabled={spinning || balance < bet}
            >
              {spinning ? (
                <span className="flex items-center">
                  <svg
                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-indigo-900"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  КРУТИМ...
                </span>
              ) : (
                "КРУТИТЬ"
              )}
            </Button>
          </motion.div>
        </div>

        {/* Ставки и линии */}
        <div className="bg-indigo-950/80 p-3 flex flex-col gap-3 backdrop-blur-sm">
          {/* Ставки */}
          <div>
            <div className="text-yellow-300 text-xs font-medium mb-2">СТАВКА:</div>
            <div className="flex flex-wrap justify-center gap-2">
              {BET_OPTIONS.map((betOption) => (
                <motion.div key={betOption} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant={bet === betOption ? "default" : "outline"}
                    className={cn(
                      "px-3 py-2 text-xs font-medium rounded-lg transition-all duration-300",
                      bet === betOption
                        ? "bg-yellow-500 text-indigo-900 border-yellow-300"
                        : "text-yellow-300 border-yellow-500",
                    )}
                    onClick={() => changeBet(betOption)}
                    disabled={spinning}
                  >
                    {betOption}
                  </Button>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Линии */}
          <div>
            <div className="text-yellow-300 text-xs font-medium mb-2">ЛИНИИ:</div>
            <div className="flex flex-wrap justify-center gap-2">
              {LINE_OPTIONS.map((lines) => (
                <motion.div key={lines} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant={activeLines === lines ? "default" : "outline"}
                    className={cn(
                      "px-3 py-2 text-xs font-medium rounded-lg transition-all duration-300",
                      activeLines === lines
                        ? "bg-yellow-500 text-indigo-900 border-yellow-300"
                        : "text-yellow-300 border-yellow-500",
                    )}
                    onClick={() => changeLines(lines)}
                    disabled={spinning}
                  >
                    {lines} ЛИНИЙ
                  </Button>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Информационные кнопки */}
        <div className="bg-indigo-950/80 p-3 flex justify-center gap-4 backdrop-blur-sm">
          <Button
            variant={showPaytable ? "default" : "outline"}
            size="sm"
            className={cn(
              "text-xs transition-all duration-300",
              showPaytable ? "bg-yellow-500 text-indigo-900" : "text-yellow-300 border-yellow-500",
            )}
            onClick={togglePaytable}
          >
            <Gift className="h-4 w-4 mr-1" />
            Призы
          </Button>

          <Button
            variant={showLines ? "default" : "outline"}
            size="sm"
            className={cn(
              "text-xs transition-all duration-300",
              showLines ? "bg-yellow-500 text-indigo-900" : "text-yellow-300 border-yellow-500",
            )}
            onClick={toggleLines}
          >
            <Sparkles className="h-4 w-4 mr-1" />
            Линии
          </Button>
        </div>

        {/* Таблица призов */}
        <AnimatePresence>
          {showPaytable && (
            <motion.div
              className="p-4 bg-indigo-900/90 text-white rounded-lg text-xs backdrop-blur-sm m-2"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="font-bold text-center text-yellow-300 mb-3 text-lg">Доступные призы</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {PRIZES.map((prize) => (
                  <motion.div
                    key={prize.id}
                    className="flex items-center gap-3 p-3 border border-indigo-700 rounded-lg bg-indigo-800/50 hover:bg-indigo-700/50 transition-colors duration-300"
                    whileHover={{ scale: 1.02, boxShadow: "0 0 8px rgba(255, 215, 0, 0.3)" }}
                  >
                    <div className="w-12 h-12 flex items-center justify-center bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-full shadow-inner p-1">
                      <div className="w-full h-full relative transform hover:scale-110 transition-transform duration-300">
                        <Image
                          src={prize.image || "/images/slots/cherry.png"}
                          alt={prize.name}
                          width={40}
                          height={40}
                          className="w-full h-full object-contain drop-shadow-lg"
                          style={{
                            filter: "drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3))",
                          }}
                        />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div
                        className={cn("font-bold text-sm", prize.id === "jackpot" ? "text-yellow-300" : "text-white")}
                      >
                        {prize.name}
                      </div>
                      <div className="text-gray-300 text-[10px] mt-1">{prize.description}</div>
                      <div className="text-yellow-300 text-[10px] mt-1">Стоимость: {prize.price} монет</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Линии выигрыша */}
        <AnimatePresence>
          {showLines && (
            <motion.div
              className="p-4 bg-indigo-900/90 text-white rounded-lg text-xs backdrop-blur-sm m-2"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="font-bold text-center text-yellow-300 mb-3 text-lg">Линии выигрыша</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {LINES.slice(0, activeLines).map((line, index) => (
                  <motion.div
                    key={index}
                    className="flex items-center gap-2 p-2 border border-indigo-700 rounded-lg cursor-pointer bg-indigo-800/50 hover:bg-indigo-700/50 transition-colors duration-300"
                    onMouseEnter={() => highlightLine(index)}
                    onMouseLeave={unhighlightLine}
                    whileHover={{ scale: 1.05 }}
                  >
                    <div
                      className="w-8 h-8 flex items-center justify-center rounded-full text-indigo-900 font-bold shadow-inner"
                      style={{ backgroundColor: line.color }}
                    >
                      {index + 1}
                    </div>
                    <div className="flex-1 text-[11px]">{line.name}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Модальное окно с призом */}
      <AnimatePresence>
        {showPrize && currentPrize && (
          <motion.div
            className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-gradient-to-b from-indigo-800 to-indigo-900 rounded-2xl border-4 border-yellow-400 p-6 max-w-md w-full shadow-[0_0_30px_rgba(79,70,229,0.5)]"
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 15 }}
            >
              <motion.h3
                className="text-2xl md:text-3xl font-bold text-center text-yellow-300 mb-4"
                initial={{ y: -20 }}
                animate={{ y: 0 }}
                transition={{ delay: 0.2 }}
              >
                {currentPrize.id === "jackpot" ? "🎉 ДЖЕКПОТ! 🎉" : "🎁 Поздравляем! 🎁"}
              </motion.h3>

              <motion.div
                className="flex justify-center mb-6"
                initial={{ scale: 0 }}
                animate={{ scale: 1, rotate: [0, 10, -10, 0] }}
                transition={{ delay: 0.3, type: "spring", damping: 10 }}
              >
                <div className="w-24 h-24 p-2 bg-gradient-to-br from-indigo-700 to-indigo-900 rounded-full shadow-inner flex items-center justify-center">
                  <div className="w-full h-full relative transform hover:scale-110 transition-transform duration-300">
                    <Image
                      src={currentPrize.image || "/images/slots/cherry.png"}
                      alt={currentPrize.name}
                      width={80}
                      height={80}
                      className="w-full h-full object-contain drop-shadow-lg"
                      style={{
                        filter: "drop-shadow(0 4px 6px rgba(0, 0, 0, 0.5))",
                      }}
                    />
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="space-y-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <h4 className="text-xl text-white text-center font-bold">{currentPrize.name}</h4>
                <p className="text-gray-300 text-center text-sm">{currentPrize.description}</p>

                <div className="bg-indigo-950 p-3 rounded-lg">
                  <p className="text-yellow-300 text-center text-sm font-medium">
                    Стоимость: {currentPrize.price} монет
                  </p>
                  <p className="text-gray-300 text-center text-xs mt-1">
                    {purchasedPrizes.includes(currentPrize.id)
                      ? "Вы уже приобрели этот приз!"
                      : balance >= currentPrize.price
                        ? "У вас достаточно монет для покупки!"
                        : `Вам не хватает ${currentPrize.price - balance} монет`}
                  </p>
                </div>
              </motion.div>

              <motion.div
                className="flex justify-center gap-4 mt-8"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
              >
                <Button
                  variant="outline"
                  className="border-yellow-400 text-yellow-300 hover:bg-indigo-800 transition-all duration-300"
                  onClick={closePrize}
                >
                  Закрыть
                </Button>

                {purchasedPrizes.includes(currentPrize.id) ? (
                  <Button
                    className="bg-gradient-to-b from-green-500 to-green-600 hover:from-green-400 hover:to-green-500 text-white font-bold transition-all duration-300"
                    onClick={claimPrize}
                  >
                    Забрать приз
                  </Button>
                ) : (
                  <Button
                    className="bg-gradient-to-b from-yellow-500 to-yellow-600 hover:from-yellow-400 hover:to-yellow-500 text-indigo-900 font-bold transition-all duration-300"
                    onClick={buyPrize}
                    disabled={balance < currentPrize.price}
                  >
                    Купить приз
                  </Button>
                )}
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Canvas для конфетти */}
      <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-50" />
    </div>
  )
}
