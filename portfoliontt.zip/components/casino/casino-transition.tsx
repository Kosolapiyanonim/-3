"use client"

import { useEffect, useRef } from "react"
import { motion } from "framer-motion"
import gsap from "gsap"

export function CasinoTransition() {
  const containerRef = useRef<HTMLDivElement>(null)
  const animationRef = useRef<gsap.Context | null>(null)

  useEffect(() => {
    if (!containerRef.current) return

    const container = containerRef.current
    const symbols = [
      "/images/slots/cherry.png",
      "/images/slots/lemon.png",
      "/images/slots/plum.png",
      "/images/slots/watermelon.png",
      "/images/slots/orange.png",
      "/images/slots/banana.png",
      "/images/slots/seven.png",
      "/images/slots/diamond.png",
      "/images/slots/wild.png",
    ]
    const numSymbols = 30
    const symbolElements: HTMLDivElement[] = []

    // Создаем контекст GSAP для лучшего управления анимациями
    animationRef.current = gsap.context(() => {
      // Анимация фона
      gsap.fromTo(
        container,
        { backgroundColor: "rgba(0, 0, 0, 0)" },
        { backgroundColor: "rgba(0, 0, 0, 0.8)", duration: 0.5 },
      )

      // Создаем и анимируем символы
      for (let i = 0; i < numSymbols; i++) {
        const symbolContainer = document.createElement("div")
        symbolContainer.className = "absolute w-16 h-16 md:w-20 md:h-20 transform transition-all duration-300"
        symbolContainer.style.left = `${Math.random() * 100}%`
        symbolContainer.style.top = "-50px"
        symbolContainer.style.opacity = "0"
        symbolContainer.style.transform = "scale(0.5) rotate(0deg)"
        symbolContainer.style.filter = "drop-shadow(0 0 10px rgba(255, 215, 0, 0.7))"

        // Создаем элемент изображения
        const img = document.createElement("img")
        img.src = symbols[Math.floor(Math.random() * symbols.length)]
        img.className = "w-full h-full object-contain"
        symbolContainer.appendChild(img)

        container.appendChild(symbolContainer)
        symbolElements.push(symbolContainer)

        // Случайная задержка для каждого символа
        const delay = Math.random() * 0.8
        const duration = 1.5 + Math.random() * 1

        // Анимация появления и падения
        gsap.to(symbolContainer, {
          opacity: 1,
          scale: 1,
          rotation: Math.random() * 360 - 180,
          y: window.innerHeight + 100,
          ease: "power1.in",
          duration: duration,
          delay: delay,
        })
      }
    }, containerRef)

    return () => {
      // Очистка при размонтировании
      if (animationRef.current) {
        animationRef.current.revert() // Отменяем все анимации
        animationRef.current = null
      }

      // Безопасно удаляем символы при размонтировании
      symbolElements.forEach((el) => {
        if (el.parentNode === container) {
          container.removeChild(el)
        }
      })
    }
  }, [])

  return (
    <motion.div
      ref={containerRef}
      className="fixed inset-0 z-50 overflow-hidden pointer-events-none backdrop-blur-sm"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    />
  )
}
