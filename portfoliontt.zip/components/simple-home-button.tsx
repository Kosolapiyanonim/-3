"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Home, ArrowLeft } from "lucide-react"

export function SimpleHomeButton() {
  const router = useRouter()
  const [isHovered, setIsHovered] = useState(false)

  const handleClick = () => {
    router.push("/")
  }

  return (
    <div className="fixed bottom-6 right-6 z-[9999]">
      <button
        className={`flex items-center justify-center rounded-full h-14 w-14 shadow-lg bg-primary text-primary-foreground transition-all duration-300 hover:scale-110 active:scale-95 ${
          isHovered ? "shadow-xl" : ""
        }`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={handleClick}
      >
        {isHovered ? <ArrowLeft className="h-6 w-6" /> : <Home className="h-6 w-6" />}
      </button>

      {isHovered && (
        <div className="absolute right-16 top-1/2 -translate-y-1/2 bg-primary text-primary-foreground px-3 py-1 rounded-md whitespace-nowrap">
          На главную
        </div>
      )}
    </div>
  )
}
