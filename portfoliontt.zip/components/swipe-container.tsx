"use client"

import type React from "react"

import { useRef, useState, type ReactNode } from "react"
import { motion } from "framer-motion"

interface SwipeContainerProps {
  children: ReactNode
  className?: string
  onSwipeLeft?: () => void
  onSwipeRight?: () => void
  threshold?: number
}

export function SwipeContainer({
  children,
  className,
  onSwipeLeft,
  onSwipeRight,
  threshold = 50,
}: SwipeContainerProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [startX, setStartX] = useState<number | null>(null)
  const [currentX, setCurrentX] = useState<number | null>(null)
  const [isSwiping, setIsSwiping] = useState(false)

  const handleTouchStart = (e: React.TouchEvent) => {
    setStartX(e.touches[0].clientX)
    setIsSwiping(true)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    if (startX !== null) {
      setCurrentX(e.touches[0].clientX)
    }
  }

  const handleTouchEnd = () => {
    if (startX !== null && currentX !== null) {
      const diff = startX - currentX

      if (diff > threshold && onSwipeLeft) {
        onSwipeLeft()
      } else if (diff < -threshold && onSwipeRight) {
        onSwipeRight()
      }
    }

    setStartX(null)
    setCurrentX(null)
    setIsSwiping(false)
  }

  return (
    <motion.div
      ref={containerRef}
      className={className}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      animate={isSwiping && currentX !== null && startX !== null ? { x: currentX - startX } : { x: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      {children}
    </motion.div>
  )
}
