"use client"

import { useEffect } from "react"
import { useTheme } from "next-themes"

export function TelegramWebAppHandler() {
  const { setTheme } = useTheme()

  useEffect(() => {
    if (typeof window !== "undefined" && window.Telegram && window.Telegram.WebApp) {
      // Сообщаем Telegram, что приложение готово
      window.Telegram.WebApp.ready()

      // Разворачиваем окно на весь экран
      if (!window.Telegram.WebApp.isExpanded) {
        window.Telegram.WebApp.expand()
      }

      // Адаптируем тему к теме Telegram
      const colorScheme = window.Telegram.WebApp.colorScheme
      if (colorScheme === "dark" || colorScheme === "light") {
        setTheme(colorScheme)
      }
    }
  }, [setTheme])

  return null
}
