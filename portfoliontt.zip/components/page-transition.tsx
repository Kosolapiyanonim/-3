"use client"

import type React from "react"

import { usePathname } from "next/navigation"
import { useEffect, useRef } from "react"
import gsap from "gsap"

interface PageTransitionProps {
  children: React.ReactNode
}

export function PageTransition({ children }: PageTransitionProps) {
  const pathname = usePathname()
  const pageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Более сдержанная анимация при входе на страницу
      gsap.fromTo(
        pageRef.current,
        {
          opacity: 0.8,
          y: 10,
        },
        {
          opacity: 1,
          y: 0,
          duration: 0.4,
          ease: "power2.out",
          clearProps: "all",
        },
      )
    }, pageRef)

    return () => ctx.revert()
  }, [pathname])

  return (
    <div ref={pageRef} className="w-full">
      {children}
    </div>
  )
}
