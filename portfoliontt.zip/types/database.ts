export interface Project {
  id: number
  title: string
  slug: string
  description: string
  content: string
  image_url: string
  tags: string[]
  category: string
  created_at: string
  updated_at: string
}

export interface CaseStudy {
  id: number
  title: string
  slug: string
  description: string
  content: string
  image_url: string
  tags: string[]
  results: string
  created_at: string
  updated_at: string
}

export interface About {
  id: number
  title: string
  content: string
  image_url?: string
  updated_at: string
}

export interface Contact {
  id: number
  type: string
  value: string
  icon?: string
  is_active: boolean
  created_at: string
}
