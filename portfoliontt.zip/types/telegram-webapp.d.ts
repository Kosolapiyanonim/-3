declare global {
  interface Window {
    Telegram: {
      WebApp: {
        ready: () => void
        expand: () => void
        isExpanded: boolean
        colorScheme: "dark" | "light"
        platform: string
        version: string
        viewportHeight: number
        viewportStableHeight: number
      }
    }
  }
}

export {}
